
CREATE TABLE public.leads_sync (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  lead_id TEXT NOT NULL UNIQUE,
  responsible_user TEXT,
  content TEXT NOT NULL,
  last_message_at TIMESTAMPTZ,
  last_message_from TEXT CHECK (last_message_from IN ('us','them')),
  followup_level INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.leads_sync ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_leads_sync_lead_id ON public.leads_sync(lead_id);

CREATE TABLE public.pending_suggestions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  lead_id TEXT NOT NULL,
  responsible_user TEXT,
  kind TEXT NOT NULL CHECK (kind IN ('live','push')),
  followup_level INT,
  suggestion_text TEXT NOT NULL,
  final_text TEXT,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','edited','skipped')),
  scheduled_for TIMESTAMPTZ,
  triggered_by_message_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.pending_suggestions ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_pending_lead_id ON public.pending_suggestions(lead_id);
CREATE INDEX idx_pending_status_kind ON public.pending_suggestions(status, kind);

CREATE TABLE public.sent_messages (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  lead_id TEXT NOT NULL,
  suggestion_id UUID,
  kind TEXT,
  message_text TEXT NOT NULL,
  responsible_user TEXT,
  webhook_status INT,
  webhook_response TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.sent_messages ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_sent_lead_id ON public.sent_messages(lead_id);

CREATE OR REPLACE FUNCTION public.touch_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;

CREATE TRIGGER trg_leads_sync_updated BEFORE UPDATE ON public.leads_sync
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER trg_pending_updated BEFORE UPDATE ON public.pending_suggestions
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


create table public.ai_suggestions (
  id uuid primary key default gen_random_uuid(),
  broker_id text not null,
  lead_id text,
  lead_name text,
  lead_company text,
  lead_stage text,
  prompt_messages jsonb not null,
  suggestion_text text not null,
  rationale text,
  model text not null default 'google/gemini-3-flash-preview',
  created_at timestamptz not null default now()
);

create index ai_suggestions_broker_created_idx
  on public.ai_suggestions (broker_id, created_at desc);

create table public.suggestion_feedback (
  id uuid primary key default gen_random_uuid(),
  suggestion_id uuid not null references public.ai_suggestions(id) on delete cascade,
  broker_id text not null,
  verdict text not null check (verdict in ('good','bad','approved','skipped','edited')),
  final_text text,
  comment text,
  created_at timestamptz not null default now()
);

create index suggestion_feedback_broker_verdict_idx
  on public.suggestion_feedback (broker_id, verdict, created_at desc);

alter table public.ai_suggestions enable row level security;
alter table public.suggestion_feedback enable row level security;
-- intentionally no policies: only server-side service role can access.

// Minimal chrome.* shim so extension/content.js runs unmodified in the Lovable
// preview iframe. Stores settings in localStorage; bridges window.postMessage
// to chrome.runtime.onMessage so the parent landing page can trigger demo
// follow-ups exactly like the real amoCRM background script does.
(function () {
  const STORE_KEY = "__copilot_preview_store";
  const listeners = [];

  // In-memory mock of pending_suggestions for preview only.
  const mockInbox = { items: [] };
  let mockSeq = 1;
  const sampleLeads = [
    { name: "Marina Volkova", lead: "8421", last: "Could you send the price for a 2-bedroom near the sea with a balcony? Any discount available?" },
    { name: "Daniel Park", lead: "9132", last: "Sounds promising. Can you confirm the floor and the view before I lock the dates?" },
    { name: "Sofía Martín", lead: "7714", last: "¿Quedan unidades con vista al mar bajo 300k? Me interesaría ver planos." },
    { name: "Yusuf Demir", lead: "8830", last: "I'm still comparing two projects. What's the payment plan for yours?" },
  ];
  function pushMock(kind) {
    const s = sampleLeads[(mockSeq - 1) % sampleLeads.length];
    const live =
      "Hi " + s.name.split(" ")[0] +
      " — saw your last note. Quick 10-min call tomorrow at 11:00 to walk through options?";
    const push =
      "Hi " + s.name.split(" ")[0] +
      " — circling back with a fresh angle: there are two new units in your range. Worth a quick look this week?";
    mockInbox.items.unshift({
      id: "mock-" + mockSeq++,
      lead_id: s.lead,
      responsible_user: "Alex",
      kind,
      followup_level: kind === "push" ? Math.ceil(Math.random() * 3) : null,
      suggestion_text: kind === "live" ? live : push,
      last_lead_text: s.last,
      triggered_by_message_at: new Date(Date.now() - 3600_000).toISOString(),
      created_at: new Date().toISOString(),
    });
  }
  // Seed one of each so the tabs aren't empty on first load.
  pushMock("live");
  pushMock("push");

  // Intercept fetches to /api/public/{suggestions,approve,skip} so the
  // preview is fully self-contained (no DB writes, no Telegram webhook).
  const realFetch = window.fetch.bind(window);
  window.fetch = function (input, init) {
    const url = typeof input === "string" ? input : input?.url || "";
    if (url.includes("/api/public/suggestions")) {
      return Promise.resolve(
        new Response(JSON.stringify({ items: mockInbox.items }), {
          status: 200,
          headers: { "Content-Type": "application/json" },
        }),
      );
    }
    if (url.includes("/api/public/approve") || url.includes("/api/public/skip")) {
      try {
        const body = init && init.body ? JSON.parse(init.body) : {};
        if (body.suggestionId) {
          mockInbox.items = mockInbox.items.filter((i) => i.id !== body.suggestionId);
        }
      } catch {}
      return Promise.resolve(
        new Response(JSON.stringify({ ok: true, hookStatus: 200 }), {
          status: 200,
          headers: { "Content-Type": "application/json" },
        }),
      );
    }
    if (url.includes("/api/public/suggest") && !url.includes("/suggestions")) {
      // Mock AI rewrite — return a tweaked variant based on feedback hint.
      let body = {};
      try { body = init && init.body ? JSON.parse(init.body) : {}; } catch {}
      const prev = String(body.previous || "");
      const fb = String(body.feedback || "").toLowerCase();
      let text = prev;
      if (fb.includes("short")) {
        text = prev.split(/[.!?]/).slice(0, 1).join(".") + ".";
      } else if (fb.includes("call")) {
        text = prev.replace(/\?$/, "") + " Could we jump on a quick call today at 3pm?";
      } else if (fb) {
        text = prev + "\n\nP.S. " + (body.feedback || "");
      } else {
        text = prev + " Let me know what timing works best.";
      }
      return Promise.resolve(
        new Response(JSON.stringify({ text, suggestionId: "mock-sugg-" + Date.now() }), {
          status: 200,
          headers: { "Content-Type": "application/json" },
        }),
      );
    }
    if (url.includes("/api/public/feedback")) {
      return Promise.resolve(
        new Response(JSON.stringify({ ok: true }), {
          status: 200,
          headers: { "Content-Type": "application/json" },
        }),
      );
    }
    return realFetch(input, init);
  };

  const defaults = {
    urlFilter: "",
    brokerName: "Alex",
    // Same-origin so /api/public/suggest and /api/public/theme just work.
    apiUrl: location.origin + "/api/public/suggest",
  };

  let store;
  try { store = JSON.parse(localStorage.getItem(STORE_KEY)) || {}; } catch { store = {}; }
  store = { ...defaults, ...store };

  window.chrome = {
    storage: {
      local: {
        get(keys, cb) {
          const out = {};
          const list = Array.isArray(keys) ? keys : (typeof keys === "string" ? [keys] : Object.keys(store));
          list.forEach((k) => { out[k] = store[k]; });
          cb && cb(out);
        },
        set(obj, cb) {
          Object.assign(store, obj);
          try { localStorage.setItem(STORE_KEY, JSON.stringify(store)); } catch {}
          cb && cb();
        },
      },
    },
    runtime: {
      onMessage: {
        addListener(fn) { listeners.push(fn); },
      },
      openOptionsPage() {
        // No options page in preview — surface a hint instead.
        window.parent?.postMessage({ type: "COPILOT_PREVIEW_OPTIONS" }, "*");
      },
    },
  };

  // Bridge postMessage -> runtime.onMessage so the landing page can fire
  // demo triggers (COPILOT_FOLLOW_UP_DUE / COPILOT_TOGGLE).
  window.addEventListener("message", (e) => {
    const msg = e.data;
    if (!msg || typeof msg !== "object" || typeof msg.type !== "string") return;
    if (!msg.type.startsWith("COPILOT_")) return;
    if (msg.type === "COPILOT_PREVIEW_ADD_LIVE") { pushMock("live"); return; }
    if (msg.type === "COPILOT_PREVIEW_ADD_PUSH") { pushMock("push"); return; }
    listeners.forEach((fn) => { try { fn(msg); } catch {} });
  });
})();
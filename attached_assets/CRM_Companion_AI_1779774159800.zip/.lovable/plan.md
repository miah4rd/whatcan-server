Понял: предыдущая правка не решила проблему, и это моя ошибка — я сделал вывод без достаточной проверки.

План исправления:

1. Убрать ручной `fetch` к `https://ai.gateway.lovable.dev/v1/chat/completions` из `src/lib/ai-suggest.ts`.
   - Сейчас именно этот путь возвращает HTML `403 Forbidden`.
   - Вместо ручных заголовков перейти на официальный AI SDK adapter `@ai-sdk/openai-compatible`, который уже установлен в проекте.

2. Создать server-only helper для Lovable AI Gateway.
   - `createOpenAICompatible({ baseURL: "https://ai.gateway.lovable.dev/v1", headers: { Lovable-API-Key, X-Lovable-AIG-SDK } })`
   - Это исключит ошибки из-за ручной сборки endpoint/headers и приведет код к поддерживаемому паттерну.

3. Переписать `generateSuggestion` на `generateText` из AI SDK.
   - Модель оставить `openai/gpt-5-nano` для минимального теста.
   - Сохранить текущий playbook, transcript, 30s timeout и понятные ошибки.
   - В логах больше не показывать даже хвост ключа.

4. Добавить честный fallback внутри `generateSuggestion`.
   - Если Gateway всё равно вернет 403, не писать пользователю «AI unavailable» как будто это временно.
   - Вернуть диагностическое сообщение: `AI Gateway rejected the request (403)` и сохранить короткую ручную рекомендацию для брокера, чтобы UI не был пустым.

5. Если после этого Gateway всё равно вернет 403, следующий реальный шаг — не менять модели по кругу, а ротировать managed `LOVABLE_API_KEY` через специальный инструмент, потому что секрет существует, но может быть не принят Gateway.
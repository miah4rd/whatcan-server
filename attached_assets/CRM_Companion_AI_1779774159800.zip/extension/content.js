(() => {
  if (window.__copilotInjected) return;
  window.__copilotInjected = true;

  const DEFAULT_GUIDE = `BROKER FOLLOW-UP PLAYBOOK\n\n1. Tone: warm, concise, confident. Address the lead by first name.\n2. Reference the last thing the lead said.\n3. Exactly ONE clear question or CTA. Under 90 words.\n4. Never apologize for following up. Never send "just checking in".\n5. Sign off as the broker, first name only.`;
  const DEFAULT_API =
    "https://project--20a7a94e-8118-4705-97e0-b0210590d173-dev.lovable.app/api/public/suggest";

  // The extension starts with an empty queue. Items are added only by explicit
  // CRM trigger messages, so page refresh can never create a fake suggestion.

  let settings = { guide: DEFAULT_GUIDE, urlFilter: "", brokerName: "Alex", apiUrl: DEFAULT_API };
  // Live theme & labels — fetched from server, overrides built-in defaults.
  // Lets cosmetic changes (CSS, button labels) ship without re-installing the extension.
  let theme = { css: null, labels: {} };
  const L = (key, fallback) => (theme.labels && theme.labels[key]) || fallback;
  // Each item: { lead, dueAt, suggestion, rationale, loading, error, generated }
  let queue = [];
  // Panel starts closed. When a follow-up becomes due, the bubble pulses with a
  // red notification dot; the panel only opens when the user clicks it.
  let collapsed = true;
  let manuallyOpen = false;    // user opened bubble while nothing is due
  let editing = false;
  let editValue = "";

  // Server-backed inbox (Live + Push). Polled from /api/public/suggestions.
  let inbox = { live: [], push: [] };
  let activeTab = "live"; // 'live' | 'push' | 'drafts'
  // When a server suggestion is opened for review, this holds its state.
  // { id, lead_id, kind, followup_level, responsible_user, text, original, busy, error }
  let openServerItem = null;

  const host = document.createElement("div");
  host.id = "__copilot_host";
  host.style.cssText = "all: initial; position: fixed; bottom: 24px; right: 24px; z-index: 2147483647; transform-origin: bottom right;";
  document.documentElement.appendChild(host);
  const root = host.attachShadow({ mode: "open" });

  // Keep widget at a constant on-screen size regardless of page zoom (Cmd +/-).
  window.__copilotBaseDpr = window.__copilotBaseDpr || window.devicePixelRatio;
  let __lastScale = 1;
  function applyZoomCompensation() {
    const zoom = window.devicePixelRatio / window.__copilotBaseDpr;
    if (!isFinite(zoom) || zoom <= 0) return;
    const s = 1 / zoom;
    if (Math.abs(s - __lastScale) < 0.01) return;
    __lastScale = s;
    host.style.transform = `scale(${s})`;
  }
  applyZoomCompensation();
  window.addEventListener("resize", applyZoomCompensation, { passive: true });

  const style = document.createElement("style");
  style.textContent = `
    :host, * { box-sizing: border-box; }
    .wrap { font-family: Roboto, -apple-system, BlinkMacSystemFont, "Segoe UI", Inter, sans-serif; color: #e6e8ee; }
    .panel { width: 420px; max-width: calc(100vw - 32px); max-height: calc(100vh - 60px); display:flex; flex-direction:column; background: #273444; border: 1px solid #3a4a5e; border-radius: 8px; box-shadow: 0 18px 48px rgba(0,0,0,.55); overflow: hidden; animation: in .25s ease-out; }
    .panel > .hd, .panel > .reason, .panel > .actions { flex: 0 0 auto; }
    .panel > .body { flex: 1 1 auto; overflow-y: auto; min-height: 0; scrollbar-width: thin; scrollbar-color: #3a4a5e transparent; }
    .panel > .body::-webkit-scrollbar { width: 8px; }
    .panel > .body::-webkit-scrollbar-thumb { background: #3a4a5e; border-radius: 4px; }
    @keyframes in { from { transform: translateY(8px); opacity: 0 } to { transform: none; opacity: 1 } }
    .hd { padding: 12px 14px; border-bottom: 1px solid #3a4a5e; background: #2c3e50; }
    .hdtop { display:flex; align-items:center; justify-content:space-between; gap:10px; }
    .badge { display:flex; align-items:center; gap: 9px; min-width: 0; flex:1; }
    .spark { width:28px; height:28px; border-radius:6px; background:#2196f3; display:grid; place-items:center; color:#fff; font-weight:900; font-size:15px; flex:none; }
    .who { font-size: 12.5px; font-weight: 800; color: #ffffff; line-height: 1.2; text-transform: uppercase; letter-spacing: .12em; }
    .who .arr { color: #5e6680; font-weight: 400; margin-left: 4px; font-size: 12px; }
    .sub { font-size: 13px; color: #8a96a8; margin-top: 4px; white-space: nowrap; overflow:hidden; text-overflow:ellipsis; max-width:280px; }
    .icons { display:flex; gap:2px; }
    .ib { width:28px; height:28px; border-radius:4px; background:transparent; border:0; color:#8a96a8; cursor:pointer; display:grid; place-items:center; font-size:16px; }
    .ib:hover { background:rgba(255,255,255,.08); color:#fff; }
    .leadbtn { width:100%; margin-top:10px; height:32px; border-radius:6px; border:1px solid #3a4a5e; background:transparent; color:#90caf9; cursor:pointer; font-size:12px; font-weight:700; display:flex; align-items:center; justify-content:center; gap:7px; }
    .leadbtn:hover { background:rgba(33,150,243,.1); border-color:#2196f3; color:#bbdefb; }
    .reason { padding: 12px 14px; background: rgba(33,150,243,.08); border-bottom: 1px solid #3a4a5e; border-left: 3px solid #2196f3; display:flex; gap:9px; align-items:flex-start; }
    .reason .icon { color:#64b5f6; font-size:17px; flex:none; margin-top:1px; }
    .reason .txt { font-size: 14px; line-height: 1.55; color:#e6e8ee; font-weight:500; }
    .reason .lbl { display:block; font-size: 11px; font-weight: 800; letter-spacing: .14em; text-transform: uppercase; color:#64b5f6; margin-bottom: 6px; }
    .body { padding: 12px 14px 10px; background:#273444; }
    .label { font-size: 11px; font-weight:700; letter-spacing:.12em; text-transform:uppercase; color:#8a96a8; margin-bottom:7px; }
    .msg { font-size: 15px; line-height: 1.6; color:#e6e8ee; white-space: pre-wrap; min-height: 80px; }
    .skel { display:flex; flex-direction:column; gap:7px; padding: 4px 0 8px; }
    .skel div { height:10px; background:rgba(255,255,255,.07); border-radius:4px; animation: p 1.2s ease-in-out infinite; }
    @keyframes p { 0%,100% {opacity:.5} 50% {opacity:1} }
    .err { color: #fca5a5; font-size: 13px; padding: 6px 0; }
    .ta { width:100%; background:#1d2a3a; color:#e6e8ee; border:1px solid #2196f3; border-radius:6px; padding:10px 12px; font-size:14.5px; font-family:inherit; resize:vertical; min-height:96px; }
    .hint { font-size: 12px; color:#8a96a8; margin-top: 7px; }
    .edittools { display:flex; gap:6px; margin-top:8px; }
    .aiinput { flex:1; height:36px; background:#1d2a3a; color:#e6e8ee; border:1px solid #3a4a5e; border-radius:6px; padding:0 10px; font-size:13.5px; font-family:inherit; }
    .mini { height:36px; border-radius:6px; border:1px solid #3a4a5e; background:transparent; color:#cfd5e3; cursor:pointer; padding:0 12px; font-size:13px; font-weight:700; }
    .mini:hover:not(:disabled) { background:rgba(255,255,255,.08); color:#fff; }
    .mini:disabled { opacity:.4; cursor:default; }
    .actions { padding: 10px 12px; border-top: 1px solid #3a4a5e; background: #2c3e50; display:grid; grid-template-columns:1fr 1fr 1fr; gap:7px; }
    .actions.editing { grid-template-columns:1fr 1fr; }
    .primary { height:40px; border:0; border-radius:4px; background:#2196f3; color:#fff; font-weight:700; font-size:13.5px; cursor:pointer; text-transform:uppercase; letter-spacing:.06em; }
    .primary:hover:not(:disabled) { background:#1e88e5; }
    .primary:disabled { opacity:.4; cursor:default; }
    .secondary { height:40px; border-radius:4px; border:1px solid #3a4a5e; background:transparent; color:#cfd5e3; cursor:pointer; font-size:13.5px; font-weight:700; text-transform:uppercase; letter-spacing:.06em; }
    .secondary:hover:not(:disabled) { background:rgba(255,255,255,.08); color:#fff; }
    .secondary:disabled { opacity:.4; cursor:default; }
    .bubble { width:52px; height:52px; border-radius:50%; background:#2196f3; color:#fff; display:grid; place-items:center; box-shadow: 0 10px 30px rgba(33,150,243,.4); cursor:pointer; border:0; font-weight:900; font-size:22px; position: relative; }
    .bubble.sleep { opacity: .55; }
    .bubble.sleep:hover { opacity: 1; }
    .bubble .dot { position:absolute; top:-3px; right:-3px; background:#ef4444; color:#fff; font-size:10px; font-weight:700; min-width:18px; height:18px; border-radius:9px; display:grid; place-items:center; padding:0 4px; border: 2px solid #273444; animation: pulse 2s infinite; }
    @keyframes pulse { 0%,100% { box-shadow: 0 0 0 0 rgba(239,68,68,.6) } 50% { box-shadow: 0 0 0 8px rgba(239,68,68,0) } }
    .detail { padding: 10px 14px 14px; border-top: 1px solid #3a4a5e; background:#1d2a3a; max-height: 220px; overflow:auto; }
    .detail .row { display:flex; gap:8px; margin-bottom: 8px; font-size: 12px; }
    .detail .k { color:#8a96a8; min-width: 64px; }
    .detail .v { color:#e6e8ee; }
    .detail .msgs { margin-top: 10px; padding-top: 10px; border-top: 1px dashed #3a4a5e; }
    .detail .m { font-size: 11.5px; line-height: 1.5; margin-bottom: 6px; color:#cfd5e3; }
    .detail .tag { display:inline-block; font-size: 9px; font-weight: 700; padding: 1px 5px; border-radius: 3px; margin-right: 6px; text-transform: uppercase; letter-spacing: .06em; }
    .tag.b { background:#3a4a5e; color:#cfd5e3; }
    .tag.l { background: rgba(33,150,243,.2); color:#64b5f6; }
    .empty { padding: 16px; text-align:center; font-size:12px; color:#8a96a8; }
    .rate { display:flex; gap:6px; margin-top:8px; align-items:center; font-size:11px; color:#8a96a8; }
    .rate .lbl { letter-spacing:.1em; text-transform:uppercase; font-weight:700; }
    .rate .rb { height:26px; padding:0 9px; border-radius:4px; border:1px solid #3a4a5e; background:transparent; color:#cfd5e3; cursor:pointer; font-size:13px; }
    .rate .rb:hover { background:rgba(255,255,255,.08); color:#fff; }
    .rate .rb.on { background:#2196f3; border-color:#2196f3; color:#fff; }
    .rate .thanks { color:#a7f3d0; font-weight:700; }
    .tabs { display:flex; gap:4px; padding: 10px 12px; background:#273444; border-bottom:1px solid #3a4a5e; flex:0 0 auto; position:relative; }
    .tabwrap { display:flex; gap:4px; padding:4px; border-radius:999px; background:rgba(33,150,243,.06); border:1px solid rgba(33,150,243,.12); width:100%; }
    .tab { flex:1; position:relative; background:transparent; border:0; color:#8a96a8; cursor:pointer; padding:7px 12px; font-size:11.5px; font-weight:700; text-transform:uppercase; letter-spacing:.08em; display:flex; align-items:center; justify-content:center; gap:7px; border-radius:999px; transition: color .18s ease, background .18s ease, box-shadow .18s ease; }
    .tab .dot { width:6px; height:6px; border-radius:50%; background:var(--mark,#8a96a8); flex:none; }
    .tab:hover { color:#cfd5e3; }
    .tab.on { color:#fff; background:linear-gradient(135deg,#2196f3,#22d3ee); box-shadow:0 6px 18px -6px rgba(33,150,243,.7), inset 0 1px 0 rgba(255,255,255,.18); }
    .tab.on .dot { background:#fff; box-shadow:0 0 6px rgba(255,255,255,.7); }
    .tab.live { --mark:#34d399; }
    .tab.push { --mark:#fbbf24; }
    .tab.drafts { --mark:#60a5fa; }
    .tab .cnt { background:rgba(255,255,255,.08); color:#cfd5e3; font-size:10px; min-width:18px; padding:1px 6px; border-radius:999px; font-weight:700; text-align:center; line-height:1.4; }
    .tab.on .cnt { background:rgba(255,255,255,.22); color:#fff; }
    .tab .pulse { width:6px; height:6px; border-radius:50%; background:#34d399; box-shadow:0 0 0 0 rgba(52,211,153,.55); animation: tabpulse 1.8s ease-out infinite; flex:none; }
    .tab.on .pulse { background:#fff; box-shadow:0 0 0 0 rgba(255,255,255,.55); }
    @keyframes tabpulse { 0% { box-shadow:0 0 0 0 rgba(52,211,153,.55) } 70% { box-shadow:0 0 0 6px rgba(52,211,153,0) } 100% { box-shadow:0 0 0 0 rgba(52,211,153,0) } }
    .list { padding: 8px 10px; display:flex; flex-direction:column; gap:8px; }
    .li { position:relative; padding:11px 13px 11px 16px; background:#1d2a3a; border:1px solid #3a4a5e; border-radius:8px; cursor:pointer; transition: border-color .15s ease, background .15s ease, transform .15s ease; overflow:hidden; }
    .li::before { content:""; position:absolute; left:0; top:0; bottom:0; width:3px; background:var(--accent,#2196f3); opacity:.7; }
    .li.live { --accent:#34d399; }
    .li.push { --accent:#fbbf24; }
    .li:hover { border-color:var(--accent,#2196f3); background:#22324a; transform: translateX(1px); }
    .li .top { display:flex; justify-content:space-between; align-items:center; gap:8px; font-size:11px; color:#8a96a8; margin-bottom:6px; }
    .li .top .lead { font-weight:700; color:#cfd5e3; letter-spacing:.02em; }
    .li .top .meta { display:flex; align-items:center; gap:6px; }
    .li .top .lvl { background:rgba(251,191,36,.15); color:#fcd34d; padding:1px 6px; border-radius:999px; font-weight:700; font-size:10px; letter-spacing:.04em; }
    .li .prv { font-size:13px; color:#e6e8ee; line-height:1.5; display:-webkit-box; -webkit-line-clamp:3; -webkit-box-orient:vertical; overflow:hidden; }
    .li .foot { margin-top:8px; display:flex; align-items:center; gap:6px; font-size:10.5px; color:#7a8699; font-weight:600; letter-spacing:.06em; text-transform:uppercase; }
    .li .foot .arrow { margin-left:auto; color:var(--accent,#2196f3); font-size:14px; opacity:.7; }
    .back { background:transparent; border:0; color:#8a96a8; cursor:pointer; font-size:12px; padding:0; display:flex; align-items:center; gap:4px; margin-bottom:4px; }
    .back:hover { color:#fff; }
  `;
  root.appendChild(style);

  const mount = document.createElement("div");
  mount.className = "wrap";
  root.appendChild(mount);

  function load() {
    chrome.storage.local.get(["guide", "urlFilter", "brokerName", "apiUrl"], (data) => {
      settings = {
        guide: data.guide || DEFAULT_GUIDE,
        urlFilter: data.urlFilter || "",
        brokerName: data.brokerName || "Alex",
        apiUrl: data.apiUrl || DEFAULT_API,
      };
      if (!matchesUrl()) { host.style.display = "none"; return; }
      host.style.display = "block";
      fetchTheme();
      queue = [];
      tick();
      setInterval(tick, 1000);
      pollInbox();
      setInterval(pollInbox, 20000);
    });
  }

  function apiBase() {
    return settings.apiUrl.replace(/\/suggest(\/)?$/, "");
  }

  async function pollInbox() {
    try {
      const url = `${apiBase()}/suggestions?responsibleUser=${encodeURIComponent(settings.brokerName || "")}`;
      const res = await fetch(url, { cache: "no-cache" });
      if (!res.ok) return;
      const json = await res.json();
      const items = Array.isArray(json.items) ? json.items : [];
      inbox = {
        live: items.filter((i) => i.kind === "live"),
        push: items.filter((i) => i.kind === "push"),
      };
      // If user has the panel open, refresh; otherwise just refresh badge.
      render();
    } catch (e) {
      // network hiccup — keep last snapshot
    }
  }

  async function approveServer(item, finalText) {
    item.busy = true; render();
    try {
      const res = await fetch(`${apiBase()}/approve`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          suggestionId: item.id,
          message: finalText,
          edited: finalText.trim() !== (item.original || "").trim(),
        }),
      });
      const json = await res.json().catch(() => ({}));
      if (!res.ok || !json.ok) {
        item.error = `Webhook ${json.hookStatus ?? res.status}`;
        item.busy = false; render();
        return;
      }
      openServerItem = null;
      await pollInbox();
    } catch (e) {
      item.error = String(e?.message || e);
      item.busy = false; render();
    }
  }

  async function skipServer(item) {
    item.busy = true; render();
    try {
      await fetch(`${apiBase()}/skip`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ suggestionId: item.id }),
      });
    } catch {}
    openServerItem = null;
    await pollInbox();
  }

  // AI rewrite for server-side suggestions: call /api/public/suggest with
  // previous text + free-form feedback, replace item.text on success.
  async function rewriteServer(item, feedback) {
    item.loading = true; item.error = ""; render();
    try {
      const res = await fetch(settings.apiUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          guide: settings.guide,
          lead: { name: `Lead ${item.lead_id}`, company: "", stage: item.kind },
          messages: item.lastLeadText
            ? [{ from: "lead", text: item.lastLeadText }]
            : [],
          brokerName: settings.brokerName,
          brokerId: settings.brokerName,
          leadId: item.lead_id,
          previous: item.text,
          feedback,
        }),
      });
      if (!res.ok) throw new Error(`API ${res.status}`);
      const json = await res.json();
      if (json?.text) item.text = json.text;
    } catch (e) {
      item.error = e?.message || "AI rewrite failed";
    } finally {
      item.loading = false; render();
    }
  }

  async function rateServer(item, verdict) {
    if (item.rated) return;
    item.rated = verdict;
    try {
      const feedbackUrl = settings.apiUrl.replace(/\/suggest(\/)?$/, "/feedback");
      await fetch(feedbackUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          suggestionId: item.id,
          brokerId: settings.brokerName,
          brokerName: settings.brokerName,
          verdict,
          finalText: item.text,
        }),
      });
    } catch {}
    render();
  }

  // Fetch live theme (CSS + labels) from the server. Same origin as the suggest API.
  async function fetchTheme() {
    try {
      const themeUrl = settings.apiUrl.replace(/\/suggest(\/)?$/, "/theme");
      const res = await fetch(themeUrl, { cache: "no-cache" });
      if (!res.ok) return;
      const json = await res.json();
      if (json?.css && typeof json.css === "string") {
        style.textContent = json.css;
      }
      if (json?.labels && typeof json.labels === "object") {
        theme.labels = json.labels;
      }
      render();
    } catch { /* keep built-in defaults */ }
  }

  function matchesUrl() {
    const filter = settings.urlFilter?.trim();
    if (!filter) return true;
    const parts = filter.split(",").map((s) => s.trim().toLowerCase()).filter(Boolean);
    const href = location.href.toLowerCase();
    return parts.some((p) => href.includes(p));
  }

  function activeItem() {
    return queue.find((q) => Date.now() >= q.dueAt) || null;
  }
  function nextDueInSec() {
    const upcoming = queue.filter((q) => Date.now() < q.dueAt).sort((a, b) => a.dueAt - b.dueAt)[0];
    return upcoming ? Math.max(0, Math.ceil((upcoming.dueAt - Date.now()) / 1000)) : null;
  }

  let lastRenderKey = "";
  function currentKey() {
    const it = activeItem();
    const waitPart = !it && manuallyOpen ? `|${Math.ceil((nextDueInSec() ?? -1) / 10)}` : "";
    const inboxPart = `|${inbox.live.length}-${inbox.push.length}|${activeTab}|${openServerItem?.id || "_"}|${openServerItem?.busy ? 1 : 0}|${openServerItem?.error || ""}`;
    return `${it?.lead.id || "_"}|${collapsed}|${manuallyOpen}|${editing}|${it?.loading ? 1 : 0}|${it?.suggestion?.length || 0}|${it?.error || ""}${waitPart}${inboxPart}`;
  }
  function tick() {
    const it = activeItem();
    if (it && !it.generated && !it.loading) {
      it.generated = true;
      generate(it);
      return;
    }
    const key = currentKey();
    if (key !== lastRenderKey) {
      render();
    }
  }

  async function generate(item, refine) {
    item.loading = true; item.error = ""; render();
    try {
      const res = await fetch(settings.apiUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          guide: settings.guide,
          lead: { name: item.lead.name, company: item.lead.company, stage: item.lead.stage },
          messages: item.lead.messages.map((m) => ({ from: m.from, text: m.text })),
          brokerName: settings.brokerName,
          brokerId: settings.brokerName,
          leadId: item.lead.id,
          previous: refine?.previous,
          feedback: refine?.feedback,
        }),
      });
      if (!res.ok) throw new Error(`API ${res.status}`);
      const json = await res.json();
      item.suggestion = json.text || "";
      item.rationale = json.rationale || "";
      item.suggestionId = json.suggestionId || null;
    } catch (e) {
      item.error = e?.message || "Failed to reach copilot API";
      item.suggestion = ""; item.rationale = "";
    } finally {
      item.loading = false; render();
    }
  }

  async function sendFeedback(item, verdict, finalText) {
    if (!item.suggestionId) return;
    try {
      const feedbackUrl = settings.apiUrl.replace(/\/suggest(\/)?$/, "/feedback");
      await fetch(feedbackUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          suggestionId: item.suggestionId,
          brokerId: settings.brokerName,
          brokerName: settings.brokerName,
          verdict,
          finalText: finalText || null,
        }),
      });
    } catch (e) {
      console.warn("feedback failed", e);
    }
  }

  function approve(item) {
    if (!item.suggestion) return;
    const links = (item.attachments || []).filter((a) => a.type === "link").map((a) => `${a.label}: ${a.url}`).join("\n");
    const text = links ? `${item.suggestion}\n\n${links}` : item.suggestion;
    navigator.clipboard.writeText(text).catch(() => {});
    sendFeedback(item, "approved", item.suggestion);
    removeFromQueue(item);
  }
  function skip(item) { sendFeedback(item, "skipped"); removeFromQueue(item); }
  function removeFromQueue(item) {
    queue = queue.filter((q) => q !== item);
    editing = false; manuallyOpen = false;
    // Next due item (if any) should also surface as a bubble, not auto-open.
    collapsed = true;
    render();
  }

  function enqueueFollowUp(lead, delayMs = 0) {
    if (!lead?.id || !lead?.name) return;
    const existing = queue.find((q) => q.lead.id === lead.id);
    const target = existing || {
      lead,
      dueAt: Date.now() + Math.max(0, delayMs),
      suggestion: "",
      rationale: "",
      suggestionId: null,
      attachments: [],
      loading: false,
      error: "",
      generated: false,
    };
    target.lead = { ...target.lead, ...lead };
    target.dueAt = Date.now() + Math.max(0, delayMs);
    if (!existing) queue.push(target);
    collapsed = true;
    manuallyOpen = false;
    render();
  }

  function render() {
    lastRenderKey = currentKey();
    mount.innerHTML = "";
    const item = activeItem();
    const total = inbox.live.length + inbox.push.length + activeCount();

    // Collapsed bubble — always visible (sleep state when nothing pending).
    if (collapsed && !manuallyOpen) {
      const cls = total === 0 ? "bubble sleep" : "bubble";
      const dot = total > 0 ? `<span class="dot">${total}</span>` : "";
      const b = el(`<button class="${cls}" title="Open copilot">✦${dot}</button>`);
      b.onclick = () => {
        collapsed = false;
        manuallyOpen = true;
        if (inbox.live.length > 0) activeTab = "live";
        else if (inbox.push.length > 0) activeTab = "push";
        else if (activeItem()) activeTab = "drafts";
        render();
      };
      mount.appendChild(b);
      return;
    }

    // Expanded panel — always wrap with tab bar.
    const panel = el(`<div class="panel"></div>`);

    // Header
    const hd = el(`
      <div class="hd">
        <div class="hdtop">
          <div class="badge">
            <div class="spark">✦</div>
            <div style="min-width:0">
              <div class="who">Copilot inbox</div>
              <div class="sub">${esc(settings.brokerName || "")}</div>
            </div>
          </div>
          <div class="icons">
            <button class="ib" data-refresh title="Refresh">⟳</button>
            <button class="ib" data-opts title="Settings">⚙</button>
            <button class="ib" data-min title="Hide">−</button>
          </div>
        </div>
      </div>
    `);
    panel.appendChild(hd);

    // Tabs
    const liveCnt = inbox.live.length;
    const pushCnt = inbox.push.length;
    const draftCnt = activeCount();
    const tabs = el(`
      <div class="tabs">
        <div class="tabwrap">
          <button class="tab live ${activeTab === "live" ? "on" : ""}" data-tab="live" title="Live replies — lead just answered">
            ${liveCnt > 0 ? '<span class="pulse"></span>' : '<span class="dot"></span>'}
            Live<span class="cnt">${liveCnt}</span>
          </button>
          <button class="tab push ${activeTab === "push" ? "on" : ""}" data-tab="push" title="Push follow-ups — silent leads">
            <span class="dot"></span>
            Push<span class="cnt">${pushCnt}</span>
          </button>
          <button class="tab drafts ${activeTab === "drafts" ? "on" : ""}" data-tab="drafts" title="Local drafts from CRM page">
            <span class="dot"></span>
            Drafts<span class="cnt">${draftCnt}</span>
          </button>
        </div>
      </div>
    `);
    panel.appendChild(tabs);

    // Body wrapper (scroll)
    const body = el(`<div class="body" style="padding:0; background:#273444"></div>`);
    panel.appendChild(body);

    if (activeTab === "live" || activeTab === "push") {
      renderServerTab(body, activeTab);
    } else {
      renderDraftsTab(body, item);
    }

    // Header wiring
    hd.querySelector("[data-opts]")?.addEventListener("click", (e) => { e.stopPropagation(); chrome.runtime.openOptionsPage?.(); });
    hd.querySelector("[data-min]")?.addEventListener("click", (e) => { e.stopPropagation(); collapsed = true; manuallyOpen = false; openServerItem = null; render(); });
    hd.querySelector("[data-refresh]")?.addEventListener("click", (e) => { e.stopPropagation(); pollInbox(); });
    tabs.querySelectorAll("[data-tab]").forEach((b) => {
      b.addEventListener("click", () => {
        activeTab = b.getAttribute("data-tab");
        openServerItem = null;
        render();
      });
    });

    mount.appendChild(panel);
  }

  // ----- Live / Push tab -----
  function renderServerTab(container, kind) {
    const list = inbox[kind] || [];

    // Editor view if a card is open — mirrors the Drafts card structure.
    if (openServerItem && openServerItem.kind === kind) {
      const it = openServerItem;
      const reason = kind === "live"
        ? `Lead ${it.lead_id} just replied${it.responsible_user ? ` (owner: ${it.responsible_user})` : ""} — keep the thread warm and reference what they said.`
        : `Silent lead ${it.lead_id} — follow-up #${it.followup_level || 1}. Soft nudge with a new angle, don't repeat your last message.`;
      const accent = kind === "live" ? "#34d399" : "#fbbf24";
      const bgTint = kind === "live" ? "rgba(52,211,153,.08)" : "rgba(251,191,36,.08)";
      const icon = "✦";
      const lbl = L("reasonLabel","Why this follow-up now");
      const quote = it.lastLeadText
        ? `<div style="margin-top:6px;color:#a7f3d0;font-style:italic">Lead: "${esc(it.lastLeadText.slice(0,120))}${it.lastLeadText.length>120?"…":""}"</div>`
        : "";
      // Reuse the exact Drafts rating helper. Force suggestionId so rating renders for server rows.
      const ratingHtml = renderRating({ suggestionId: it.id, rated: it.rated });
      const view = el(`
        <div>
          <div style="padding:8px 14px 0;">
            <button class="back" data-back>← Back to ${kind === "live" ? "Live" : "Push"}</button>
          </div>
          <div class="reason" style="border-left-color:${accent};background:${bgTint}">
            <span class="icon" style="color:${accent}">${icon}</span>
            <div class="txt">
              <span class="lbl" style="color:${accent}">${lbl}</span>
              ${esc(reason)}
              ${quote}
            </div>
          </div>

          <div class="body" style="background:transparent;padding:12px 14px 10px">
            <div class="label">${esc(editing ? L("editLabel","Edit message") : L("suggestedLabel","Suggested message"))}</div>
            ${it.loading
              ? `<div class="skel"><div style="width:100%"></div><div style="width:92%"></div><div style="width:80%"></div><div style="width:60%"></div></div>`
              : editing
                ? `<textarea class="ta" data-ed placeholder="Edit the message manually">${esc(editValue)}</textarea>
                   ${renderAttachments(it)}
                   <div class="edittools">
                     <input class="aiinput" data-ai placeholder="${esc(L("aiPlaceholder","Tell AI what to change, or use voice…"))}">
                     <button class="mini" data-voice title="Voice">🎙</button>
                     <button class="mini" data-attach title="Attach screenshot">📎</button>
                     <button class="mini" data-rewrite ${it.loading ? "disabled" : ""}>${esc(L("aiRewriteBtn","AI rewrite"))}</button>
                   </div>
                   <input type="file" data-fileinput accept="image/*" style="display:none">
                   <div class="hint">${esc(L("editHint","Edit manually, type an instruction, or dictate it with the mic."))}</div>`
                : `<div class="msg">${esc(it.text)}</div>${renderAttachments(it)}${ratingHtml}`}
            ${it.error ? `<div class="err" style="margin-top:8px">${esc(it.error)}</div>` : ""}
          </div>

          <div class="actions ${editing ? "editing" : ""}">
            ${editing
              ? `<button class="primary" data-savedit>${esc(L("saveBtn","✓ Save"))}</button>
                 <button class="secondary" data-canceledit>${esc(L("cancelBtn","Cancel"))}</button>`
              : `<button class="primary" data-approve ${it.busy || it.loading ? "disabled" : ""}>${it.busy ? "Sending…" : esc(L("approveBtn","✓ Approve"))}</button>
                 <button class="secondary" data-skip ${it.busy ? "disabled" : ""}>${esc(L("skipBtn","✕ Skip"))}</button>
                 <button class="secondary" data-edit ${it.busy || it.loading ? "disabled" : ""}>${esc(L("editBtn","✎ Edit"))}</button>`}
          </div>
        </div>
      `);
      view.querySelector("[data-back]").onclick = () => { openServerItem = null; editing = false; render(); };
      view.querySelector("[data-approve]")?.addEventListener("click", () => {
        const links = (it.attachments || []).filter((a) => a.type === "link").map((a) => `${a.label}: ${a.url}`).join("\n");
        approveServer(it, links ? `${it.text}\n\n${links}` : it.text);
      });
      view.querySelector("[data-skip]")?.addEventListener("click", () => skipServer(it));
      view.querySelector("[data-edit]")?.addEventListener("click", () => { editing = true; editValue = it.text; render(); });
      view.querySelector("[data-savedit]")?.addEventListener("click", () => { it.text = editValue; editing = false; render(); });
      view.querySelector("[data-canceledit]")?.addEventListener("click", () => { editing = false; render(); });
      view.querySelector("[data-voice]")?.addEventListener("click", () => startVoice(view));
      view.querySelector("[data-rewrite]")?.addEventListener("click", () => {
        const fb = view.querySelector("[data-ai]")?.value?.trim() || "Rewrite this draft using the manual edits as guidance.";
        if (editValue && editValue !== it.text) it.text = editValue;
        rewriteServer(it, fb);
        editing = false; editValue = "";
      });
      const fileInput = view.querySelector("[data-fileinput]");
      view.querySelector("[data-attach]")?.addEventListener("click", () => fileInput?.click());
      fileInput?.addEventListener("change", (e) => {
        const file = e.target.files?.[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = () => {
          it.attachments = it.attachments || [];
          it.attachments.push({ type: "image", url: reader.result, name: file.name });
          render();
        };
        reader.readAsDataURL(file);
      });
      view.querySelectorAll("[data-rmattach]").forEach((btn) => {
        btn.addEventListener("click", () => {
          const idx = Number(btn.getAttribute("data-rmattach"));
          it.attachments.splice(idx, 1);
          render();
        });
      });
      view.querySelectorAll("[data-rate]").forEach((btn) => {
        btn.addEventListener("click", () => {
          const v = btn.getAttribute("data-rate");
          if (v === "good" || v === "bad") rateServer(it, v);
        });
      });
      const ed = view.querySelector("[data-ed]");
      if (ed) ed.addEventListener("input", (e) => { editValue = e.target.value; });
      container.appendChild(view);
      return;
    }

    if (list.length === 0) {
      const empty = kind === "live"
        ? "All live replies handled. New ones will appear here as leads respond."
        : "No silent leads right now. Scheduled follow-ups will land here when they're due.";
      const icon = kind === "live" ? "⚡" : "⏰";
      container.appendChild(el(`
        <div class="empty" style="padding:36px 18px;display:flex;flex-direction:column;align-items:center;gap:10px">
          <div style="width:44px;height:44px;border-radius:50%;display:grid;place-items:center;font-size:20px;background:${kind==="live"?"rgba(52,211,153,.12)":"rgba(251,191,36,.12)"};color:${kind==="live"?"#34d399":"#fbbf24"}">${icon}</div>
          <div style="color:#cfd5e3;font-weight:600;font-size:13px">All caught up</div>
          <div style="font-size:12px;line-height:1.5;max-width:240px">${empty}</div>
        </div>
      `));
      return;
    }

    const ul = el(`<div class="list"></div>`);
    for (const row of list) {
      const li = el(`
        <div class="li ${kind}" data-id="${esc(row.id)}">
          <div class="top">
            <span class="lead">Lead ${esc(row.lead_id)}</span>
            <span class="meta">
              ${row.followup_level ? `<span class="lvl">#${row.followup_level}</span>` : ""}
              <span>${esc(fmtAgo(row.created_at))}</span>
            </span>
          </div>
          <div class="prv">${esc(row.suggestion_text || "")}</div>
          <div class="foot">
            <span>${row.responsible_user ? esc(row.responsible_user) : (kind === "live" ? "Live reply" : "Push follow-up")}</span>
            <span class="arrow">›</span>
          </div>
        </div>
      `);
      li.onclick = () => {
        openServerItem = {
          id: row.id,
          lead_id: row.lead_id,
          kind: row.kind,
          followup_level: row.followup_level,
          responsible_user: row.responsible_user,
          text: row.suggestion_text || "",
          original: row.suggestion_text || "",
          lastLeadText: row.last_lead_text || "",
          attachments: [],
          rated: null,
          loading: false,
          busy: false,
          error: "",
        };
        editing = false;
        render();
      };
      ul.appendChild(li);
    }
    container.appendChild(ul);
  }

  // ----- Drafts tab (legacy local-queue flow) -----
  function renderDraftsTab(container, item) {
    if (!item) {
      const wait = nextDueInSec();
      const next = [...queue].sort((a,b)=>a.dueAt-b.dueAt)[0];
      container.appendChild(el(`<div class="empty" style="padding:32px 14px">${next ? `Next draft: ${esc(next.lead.name)} in ${fmtWait(wait || 0)}` : "No local drafts from the CRM yet."}</div>`));
      return;
    }
    container.appendChild(renderDraftCard(item));
  }

  function renderDraftCard(item) {
    const { lead } = item;
    const lastLead = [...lead.messages].reverse().find((m) => m.from === "lead");
    const reason = item.rationale || `${lead.trigger || ""} Playbook says: reference the lead's last point and use one clear CTA.`;
    const panel = el(`
      <div>
        <div class="reason">
          <span class="icon">✦</span>
          <div class="txt">
            <span class="lbl">${esc(L("reasonLabel","Why this follow-up now"))}</span>
            ${esc(reason)}
            ${lastLead ? `<div style="margin-top:6px;color:#a7f3d0;font-style:italic">Lead: "${esc(lastLead.text.slice(0,120))}${lastLead.text.length>120?"…":""}"</div>` : ""}
          </div>
        </div>

        <div class="body" style="background:transparent;padding:12px 14px 10px">
          <div class="label">${esc(editing ? L("editLabel","Edit message") : L("suggestedLabel","Suggested message"))}</div>
          ${item.loading && !item.suggestion ? `<div class="skel"><div style="width:100%"></div><div style="width:92%"></div><div style="width:80%"></div><div style="width:60%"></div></div>` :
            item.error ? `<div class="err">${esc(item.error)}</div>` :
            editing ? `<textarea class="ta" data-ed placeholder="Edit the message manually">${esc(editValue)}</textarea>${renderAttachments(item)}<div class="edittools"><input class="aiinput" data-ai placeholder="${esc(L("aiPlaceholder","Tell AI what to change, or use voice…"))}"><button class="mini" data-voice title="Voice">🎙</button><button class="mini" data-attach title="Attach screenshot or file">📎</button><button class="mini" data-rewrite ${item.loading ? "disabled" : ""}>${esc(L("aiRewriteBtn","AI rewrite"))}</button></div><input type="file" data-fileinput accept="image/*" style="display:none"><div class="hint">${esc(L("editHint","Edit manually, type an instruction, or dictate it with the mic."))}</div>` :
            `<div class="msg">${esc(item.suggestion)}</div>${renderAttachments(item)}${renderRating(item)}`}
        </div>

        <div class="actions ${editing ? "editing" : ""}">
          ${editing ? `
            <button class="primary" data-savedit>${esc(L("saveBtn","✓ Save"))}</button>
            <button class="secondary" data-canceledit>${esc(L("cancelBtn","Cancel"))}</button>
          ` : `
            <button class="primary" data-approve ${!item.suggestion || item.loading ? "disabled" : ""}>${esc(L("approveBtn","✓ Approve"))}</button>
            <button class="secondary" data-skip>${esc(L("skipBtn","✕ Skip"))}</button>
            <button class="secondary" data-edit ${!item.suggestion ? "disabled" : ""}>${esc(L("editBtn","✎ Edit"))}</button>
          `}
        </div>
      </div>`);

    panel.querySelector("[data-openlead]")?.addEventListener("click", (e) => { e.stopPropagation(); /* link handles navigation */ });
    panel.querySelector("[data-approve]")?.addEventListener("click", () => approve(item));
    panel.querySelector("[data-skip]")?.addEventListener("click", () => skip(item));
    panel.querySelector("[data-edit]")?.addEventListener("click", () => { editing = true; editValue = item.suggestion; render(); });
    panel.querySelector("[data-savedit]")?.addEventListener("click", () => { item.suggestion = editValue; editing = false; render(); });
    panel.querySelector("[data-canceledit]")?.addEventListener("click", () => { editing = false; render(); });
    panel.querySelectorAll("[data-rate]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const v = btn.getAttribute("data-rate");
        if (v !== "good" && v !== "bad") return;
        item.rated = v;
        sendFeedback(item, v, item.suggestion);
        render();
      });
    });
    panel.querySelector("[data-rewrite]")?.addEventListener("click", () => {
      const fb = panel.querySelector("[data-ai]")?.value?.trim() || "Rewrite this draft using the manual edits as guidance.";
      if (!fb) return;
      generate(item, { previous: item.suggestion, feedback: fb });
      editing = false; editValue = "";
    });
    panel.querySelector("[data-voice]")?.addEventListener("click", () => startVoice(panel));
    const fileInput = panel.querySelector("[data-fileinput]");
    panel.querySelector("[data-attach]")?.addEventListener("click", () => fileInput?.click());
    fileInput?.addEventListener("change", (e) => {
      const file = e.target.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = () => {
        item.attachments = item.attachments || [];
        item.attachments.push({ type: "image", url: reader.result, name: file.name });
        render();
      };
      reader.readAsDataURL(file);
    });
    panel.querySelectorAll("[data-rmattach]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const idx = Number(btn.getAttribute("data-rmattach"));
        item.attachments.splice(idx, 1);
        render();
      });
    });
    const ed = panel.querySelector("[data-ed]");
    if (ed) ed.addEventListener("input", (e) => { editValue = e.target.value; });

    return panel;
  }

  function renderDetail(lead) {
    return `<div class="detail">
      <div class="row"><div class="k">Stage</div><div class="v">${esc(lead.stage)}</div></div>
      <div class="row"><div class="k">Company</div><div class="v">${esc(lead.company)}</div></div>
      <div class="row"><div class="k">Silent</div><div class="v">${lead.lastContactDays} day(s)</div></div>
      <div class="msgs">
        <div class="label" style="margin-bottom:6px">Recent thread</div>
        ${lead.messages.slice(-5).map((m) => `<div class="m"><span class="tag ${m.from === "broker" ? "b" : "l"}">${m.from === "broker" ? "You" : "Lead"}</span>${esc(m.text)}</div>`).join("")}
      </div>
    </div>`;
  }

  function activeCount() { return queue.filter((q) => Date.now() >= q.dueAt).length; }
  function renderAttachments(item) {
    if (!item.attachments?.length) return "";
    return `<div class="atts">${item.attachments.map((a, i) => {
      const rm = `<button class="attrm" data-rmattach="${i}" title="Remove">×</button>`;
      if (a.type === "image") {
        return `<div class="att img"><img src="${esc(a.url)}" alt="${esc(a.name||"")}">${rm}</div>`;
      }
      return `<div class="att link"><span class="ai">🔗</span><a href="${esc(a.url)}" target="_blank" rel="noopener">${esc(a.label||a.url)}</a>${rm}</div>`;
    }).join("")}</div>`;
  }
  function renderRating(item) {
    if (!item.suggestionId) return "";
    if (item.rated) {
      return `<div class="rate"><span class="thanks">${item.rated === "good" ? "✓ Marked as good — will reuse this style" : "✓ Marked as bad — will avoid this style"}</span></div>`;
    }
    return `<div class="rate"><span class="lbl">Train AI:</span><button class="rb" data-rate="good" title="Good example — copy this style">👍 Good</button><button class="rb" data-rate="bad" title="Bad example — don't write like this">👎 Bad</button></div>`;
  }
  function startVoice(panel) {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const input = panel.querySelector("[data-ai]");
    if (!SpeechRecognition || !input) return;
    const recognition = new SpeechRecognition();
    recognition.lang = "en-US";
    recognition.onresult = (event) => {
      const text = event.results?.[0]?.[0]?.transcript || "";
      input.value = input.value ? `${input.value} ${text}` : text;
    };
    recognition.start();
  }
  function fmtWait(s) { if (s < 60) return `${s}s`; const m = Math.floor(s/60); return `${m}m`; }
  function fmtAgo(iso) {
    if (!iso) return "";
    const s = Math.max(0, Math.floor((Date.now() - new Date(iso).getTime()) / 1000));
    if (s < 60) return `${s}s ago`;
    const m = Math.floor(s / 60);
    if (m < 60) return `${m}m ago`;
    const h = Math.floor(m / 60);
    if (h < 24) return `${h}h ago`;
    return `${Math.floor(h / 24)}d ago`;
  }
  function esc(s) { return String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c])); }
  function el(html) { const t = document.createElement("template"); t.innerHTML = html.trim(); return t.content.firstElementChild; }

  chrome.runtime.onMessage.addListener((m) => {
    if (m?.type === "COPILOT_TOGGLE") {
      if (activeItem()) { collapsed = !collapsed; } else { manuallyOpen = !manuallyOpen; }
      render();
    }
    if (m?.type === "COPILOT_FOLLOW_UP_DUE") {
      enqueueFollowUp(m.lead, Number(m.delayMs || 0));
    }
  });

  load();
})();

// Open options page on first install so the broker can set playbook & API.
chrome.runtime.onInstalled.addListener(({ reason }) => {
  if (reason === "install") {
    chrome.runtime.openOptionsPage();
  }
});

// Toolbar icon click → toggle popup visibility on the active tab.
chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.id) return;
  try {
    await chrome.tabs.sendMessage(tab.id, { type: "COPILOT_TOGGLE" });
  } catch {
    // content script not injected on this page (e.g. chrome:// URL)
  }
});
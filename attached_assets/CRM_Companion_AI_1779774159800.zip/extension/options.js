const DEFAULT_GUIDE = `BROKER FOLLOW-UP PLAYBOOK

1. Tone: warm, concise, confident. No corporate fluff. Always address the lead by first name.
2. Cadence:
   - No reply in 24h after initial pitch -> soft nudge with new angle (value, case study).
   - No reply in 72h -> break-up email offering to pause.
   - After demo/call -> recap within 4h, list 2 next steps, propose specific time.
3. Every follow-up must:
   - Reference the last thing the lead said (continuity).
   - Include exactly ONE clear question or CTA.
   - Stay under 90 words.
4. Never:
   - Apologize for following up.
   - Send generic "just checking in".
   - Send pricing in writing before a discovery call.
5. If the lead mentions budget, timeline, or competitors -> flag for a call, do NOT reply in text.
6. Sign off as the broker, first name only.`;

const DEFAULT_API =
  "https://project--20a7a94e-8118-4705-97e0-b0210590d173-dev.lovable.app/api/public/suggest";

const $ = (id) => document.getElementById(id);

chrome.storage.local.get(["guide", "urlFilter", "brokerName", "apiUrl"], (data) => {
  $("guide").value = data.guide || DEFAULT_GUIDE;
  $("urlFilter").value = data.urlFilter || "";
  $("brokerName").value = data.brokerName || "Alex";
  $("apiUrl").value = data.apiUrl || DEFAULT_API;
});

$("save").addEventListener("click", () => {
  chrome.storage.local.set(
    {
      guide: $("guide").value.trim() || DEFAULT_GUIDE,
      urlFilter: $("urlFilter").value.trim(),
      brokerName: $("brokerName").value.trim() || "Alex",
      apiUrl: $("apiUrl").value.trim() || DEFAULT_API,
    },
    () => {
      $("status").textContent = "Saved.";
      setTimeout(() => ($("status").textContent = ""), 1500);
    },
  );
});

$("reset").addEventListener("click", () => {
  $("guide").value = DEFAULT_GUIDE;
});
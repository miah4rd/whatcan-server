export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      ai_suggestions: {
        Row: {
          broker_id: string
          created_at: string
          id: string
          lead_company: string | null
          lead_id: string | null
          lead_name: string | null
          lead_stage: string | null
          model: string
          prompt_messages: Json
          rationale: string | null
          suggestion_text: string
        }
        Insert: {
          broker_id: string
          created_at?: string
          id?: string
          lead_company?: string | null
          lead_id?: string | null
          lead_name?: string | null
          lead_stage?: string | null
          model?: string
          prompt_messages: Json
          rationale?: string | null
          suggestion_text: string
        }
        Update: {
          broker_id?: string
          created_at?: string
          id?: string
          lead_company?: string | null
          lead_id?: string | null
          lead_name?: string | null
          lead_stage?: string | null
          model?: string
          prompt_messages?: Json
          rationale?: string | null
          suggestion_text?: string
        }
        Relationships: []
      }
      leads_sync: {
        Row: {
          content: string
          created_at: string
          followup_level: number
          id: string
          last_message_at: string | null
          last_message_from: string | null
          lead_id: string
          responsible_user: string | null
          updated_at: string
        }
        Insert: {
          content: string
          created_at?: string
          followup_level?: number
          id?: string
          last_message_at?: string | null
          last_message_from?: string | null
          lead_id: string
          responsible_user?: string | null
          updated_at?: string
        }
        Update: {
          content?: string
          created_at?: string
          followup_level?: number
          id?: string
          last_message_at?: string | null
          last_message_from?: string | null
          lead_id?: string
          responsible_user?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      pending_suggestions: {
        Row: {
          created_at: string
          final_text: string | null
          followup_level: number | null
          id: string
          kind: string
          lead_id: string
          responsible_user: string | null
          scheduled_for: string | null
          status: string
          suggestion_text: string
          triggered_by_message_at: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          final_text?: string | null
          followup_level?: number | null
          id?: string
          kind: string
          lead_id: string
          responsible_user?: string | null
          scheduled_for?: string | null
          status?: string
          suggestion_text: string
          triggered_by_message_at?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          final_text?: string | null
          followup_level?: number | null
          id?: string
          kind?: string
          lead_id?: string
          responsible_user?: string | null
          scheduled_for?: string | null
          status?: string
          suggestion_text?: string
          triggered_by_message_at?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      sent_messages: {
        Row: {
          created_at: string
          id: string
          kind: string | null
          lead_id: string
          message_text: string
          responsible_user: string | null
          suggestion_id: string | null
          webhook_response: string | null
          webhook_status: number | null
        }
        Insert: {
          created_at?: string
          id?: string
          kind?: string | null
          lead_id: string
          message_text: string
          responsible_user?: string | null
          suggestion_id?: string | null
          webhook_response?: string | null
          webhook_status?: number | null
        }
        Update: {
          created_at?: string
          id?: string
          kind?: string | null
          lead_id?: string
          message_text?: string
          responsible_user?: string | null
          suggestion_id?: string | null
          webhook_response?: string | null
          webhook_status?: number | null
        }
        Relationships: []
      }
      suggestion_feedback: {
        Row: {
          broker_id: string
          comment: string | null
          created_at: string
          final_text: string | null
          id: string
          suggestion_id: string
          verdict: string
        }
        Insert: {
          broker_id: string
          comment?: string | null
          created_at?: string
          final_text?: string | null
          id?: string
          suggestion_id: string
          verdict: string
        }
        Update: {
          broker_id?: string
          comment?: string | null
          created_at?: string
          final_text?: string | null
          id?: string
          suggestion_id?: string
          verdict?: string
        }
        Relationships: [
          {
            foreignKeyName: "suggestion_feedback_suggestion_id_fkey"
            columns: ["suggestion_id"]
            isOneToOne: false
            referencedRelation: "ai_suggestions"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const

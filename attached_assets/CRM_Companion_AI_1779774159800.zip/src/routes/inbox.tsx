import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";

type Suggestion = {
  id: string;
  lead_id: string;
  responsible_user: string | null;
  kind: "live" | "push";
  followup_level: number | null;
  suggestion_text: string;
  triggered_by_message_at: string | null;
  created_at: string;
};

export const Route = createFileRoute("/inbox")({
  component: InboxPage,
  head: () => ({
    meta: [
      { title: "Inbox — Live & Push follow-ups" },
      {
        name: "description",
        content:
          "Review AI follow-up suggestions for live replies and scheduled push cadences.",
      },
    ],
  }),
});

function InboxPage() {
  return (
    <main className="min-h-screen bg-background text-foreground">
      <div className="mx-auto max-w-4xl px-6 py-10">
        <header className="mb-8">
          <h1 className="text-3xl font-semibold tracking-tight">Inbox</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            <span className="font-medium">Live</span> — клиент только что ответил.{" "}
            <span className="font-medium">Push</span> — клиент молчит, запущен
            фолоап-сет.
          </p>
        </header>

        <Tabs defaultValue="live" className="w-full">
          <TabsList>
            <TabsTrigger value="live">Live</TabsTrigger>
            <TabsTrigger value="push">Push</TabsTrigger>
          </TabsList>
          <TabsContent value="live" className="mt-6">
            <SuggestionList kind="live" />
          </TabsContent>
          <TabsContent value="push" className="mt-6">
            <SuggestionList kind="push" />
          </TabsContent>
        </Tabs>
      </div>
    </main>
  );
}

function SuggestionList({ kind }: { kind: "live" | "push" }) {
  const [items, setItems] = useState<Suggestion[] | null>(null);
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    let cancelled = false;
    fetch(`/api/public/suggestions?kind=${kind}`)
      .then((r) => r.json())
      .then((j) => {
        if (!cancelled) setItems(j.items ?? []);
      })
      .catch(() => {
        if (!cancelled) setItems([]);
      });
    return () => {
      cancelled = true;
    };
  }, [kind, reloadKey]);

  if (items === null) {
    return <p className="text-sm text-muted-foreground">Загрузка…</p>;
  }
  if (items.length === 0) {
    return (
      <Card className="p-8 text-center text-sm text-muted-foreground">
        Пока нет ожидающих {kind === "live" ? "Live" : "Push"} саджестов.
      </Card>
    );
  }
  return (
    <div className="space-y-4">
      {items.map((s) => (
        <SuggestionCard
          key={s.id}
          s={s}
          onDone={() => setReloadKey((k) => k + 1)}
        />
      ))}
    </div>
  );
}

function SuggestionCard({
  s,
  onDone,
}: {
  s: Suggestion;
  onDone: () => void;
}) {
  const [text, setText] = useState(s.suggestion_text);
  const [busy, setBusy] = useState(false);

  const send = async () => {
    setBusy(true);
    try {
      const r = await fetch("/api/public/approve", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          suggestionId: s.id,
          message: text,
          edited: text.trim() !== s.suggestion_text.trim(),
        }),
      });
      const j = await r.json().catch(() => ({}));
      if (r.ok && j.ok) {
        toast.success("Отправлено");
        onDone();
      } else {
        toast.error(`Ошибка: hook ${j.hookStatus ?? r.status}`);
      }
    } catch (e) {
      toast.error(String(e));
    } finally {
      setBusy(false);
    }
  };

  const skip = async () => {
    setBusy(true);
    try {
      // mark skipped via approve endpoint? We don't have one — call suggestions PATCH via approve hack.
      // Simplest: call approve with empty? No. Use a dedicated lightweight call:
      await fetch("/api/public/skip", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ suggestionId: s.id }),
      });
      onDone();
    } finally {
      setBusy(false);
    }
  };

  return (
    <Card className="p-5">
      <div className="mb-3 flex items-center gap-2 text-xs text-muted-foreground">
        <Badge variant="secondary">Lead {s.lead_id}</Badge>
        {s.responsible_user && <span>· {s.responsible_user}</span>}
        {s.kind === "push" && s.followup_level && (
          <Badge>followup #{s.followup_level}</Badge>
        )}
        <span className="ml-auto">
          {new Date(s.created_at).toLocaleString()}
        </span>
      </div>
      <Textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        rows={6}
        className="font-sans text-sm"
      />
      <div className="mt-3 flex gap-2">
        <Button onClick={send} disabled={busy || !text.trim()}>
          Approve & send
        </Button>
        <Button variant="ghost" onClick={skip} disabled={busy}>
          Skip
        </Button>
      </div>
    </Card>
  );
}
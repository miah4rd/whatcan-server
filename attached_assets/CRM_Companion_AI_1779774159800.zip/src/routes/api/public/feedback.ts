import { createFileRoute } from "@tanstack/react-router";
import "@tanstack/react-start";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
};

type Body = {
  suggestionId: string;
  brokerId?: string;
  brokerName?: string;
  verdict: "good" | "bad" | "approved" | "skipped" | "edited";
  finalText?: string;
  comment?: string;
};

const VERDICTS = new Set(["good", "bad", "approved", "skipped", "edited"]);

export const Route = createFileRoute("/api/public/feedback")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: CORS }),
      POST: async ({ request }: { request: Request }) => {
        let body: Body;
        try {
          body = (await request.json()) as Body;
        } catch {
          return new Response("Invalid JSON", { status: 400, headers: CORS });
        }

        if (
          !body?.suggestionId ||
          typeof body.suggestionId !== "string" ||
          body.suggestionId.length > 64 ||
          !VERDICTS.has(body.verdict) ||
          (body.finalText && body.finalText.length > 8000) ||
          (body.comment && body.comment.length > 1000)
        ) {
          return new Response("Invalid payload", { status: 400, headers: CORS });
        }

        const brokerId = (body.brokerId || body.brokerName || "anon")
          .toLowerCase()
          .slice(0, 64);

        const { error } = await supabaseAdmin.from("suggestion_feedback").insert({
          suggestion_id: body.suggestionId,
          broker_id: brokerId,
          verdict: body.verdict,
          final_text: body.finalText ?? null,
          comment: body.comment ?? null,
        });

        if (error) {
          console.error("feedback insert error", error);
          return new Response(`DB error: ${error.message}`, { status: 500, headers: CORS });
        }

        return new Response(JSON.stringify({ ok: true }), {
          status: 200,
          headers: { ...CORS, "Content-Type": "application/json" },
        });
      },
    },
  },
});
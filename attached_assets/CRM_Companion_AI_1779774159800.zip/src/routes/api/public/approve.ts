import { createFileRoute } from "@tanstack/react-router";
import "@tanstack/react-start";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
};

const HOOK_URL = "https://hooks.tglk.ru/in/p5dmPxJ7zyLkZ1HLlPSmaJ24ZQXz9a";

type Body = {
  suggestionId: string;
  message: string;
  edited?: boolean;
};

export const Route = createFileRoute("/api/public/approve")({
  server: {
    handlers: {
      OPTIONS: async () =>
        new Response(null, { status: 204, headers: CORS }),
      POST: async ({ request }: { request: Request }) => {
        let body: Body;
        try {
          body = (await request.json()) as Body;
        } catch {
          return new Response("Invalid JSON", { status: 400, headers: CORS });
        }
        if (
          !body?.suggestionId ||
          typeof body.suggestionId !== "string" ||
          !body.message ||
          typeof body.message !== "string" ||
          body.message.length > 8000
        ) {
          return new Response("Invalid payload", { status: 400, headers: CORS });
        }

        const { data: sug, error: sErr } = await supabaseAdmin
          .from("pending_suggestions")
          .select("id, lead_id, kind, responsible_user, status")
          .eq("id", body.suggestionId)
          .maybeSingle();
        if (sErr || !sug) {
          return new Response("Suggestion not found", { status: 404, headers: CORS });
        }
        if (sug.status !== "pending") {
          return new Response("Already processed", { status: 409, headers: CORS });
        }

        // Send to telegram-style webhook
        let hookStatus = 0;
        let hookBody = "";
        try {
          const r = await fetch(HOOK_URL, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ leadId: sug.lead_id, message: body.message }),
          });
          hookStatus = r.status;
          hookBody = (await r.text()).slice(0, 1000);
        } catch (e) {
          console.error("webhook error", e);
          hookBody = String(e).slice(0, 1000);
        }

        await supabaseAdmin
          .from("pending_suggestions")
          .update({
            status: body.edited ? "edited" : "approved",
            final_text: body.message,
          })
          .eq("id", body.suggestionId);

        await supabaseAdmin.from("sent_messages").insert({
          lead_id: sug.lead_id,
          suggestion_id: sug.id,
          kind: sug.kind,
          message_text: body.message,
          responsible_user: sug.responsible_user,
          webhook_status: hookStatus,
          webhook_response: hookBody,
        });

        // Mark our outbound: bump followup level so push cadence advances
        // and last_message_from becomes "us" until the next sync overrides.
        await supabaseAdmin
          .from("leads_sync")
          .update({
            last_message_at: new Date().toISOString(),
            last_message_from: "us",
            followup_level: sug.kind === "push" ? undefined : 0,
          })
          .eq("lead_id", sug.lead_id);

        return new Response(
          JSON.stringify({ ok: hookStatus >= 200 && hookStatus < 300, hookStatus }),
          {
            status: 200,
            headers: { ...CORS, "Content-Type": "application/json" },
          },
        );
      },
    },
  },
});
import { createFileRoute } from "@tanstack/react-router";
import "@tanstack/react-start";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { parseConversation, lastMessage } from "@/lib/conversation-parser";
import { generateSuggestion, upsertPendingSuggestion } from "@/lib/ai-suggest";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
};

type Body = {
  content: string;
  leadId: string | number;
  responsibleUser?: string;
};

export const Route = createFileRoute("/api/public/lead-sync")({
  server: {
    handlers: {
      OPTIONS: async () =>
        new Response(null, { status: 204, headers: CORS }),
      POST: async ({ request }: { request: Request }) => {
        let body: Body;
        try {
          body = (await request.json()) as Body;
        } catch {
          return new Response("Invalid JSON", { status: 400, headers: CORS });
        }

        const leadId = String(body.leadId ?? "").trim();
        const content = String(body.content ?? "");
        const responsibleUser =
          typeof body.responsibleUser === "string"
            ? body.responsibleUser.slice(0, 200)
            : null;

        if (!leadId || leadId.length > 64 || !content || content.length > 200_000) {
          return new Response("Invalid payload", { status: 400, headers: CORS });
        }

        const msgs = parseConversation(content);
        const last = lastMessage(msgs);

        // Upsert lead snapshot
        const { error: upErr } = await supabaseAdmin
          .from("leads_sync")
          .upsert(
            {
              lead_id: leadId,
              responsible_user: responsibleUser,
              content,
              last_message_at: last ? last.at.toISOString() : null,
              last_message_from: last ? last.who : null,
              // reset followup ladder if a new message landed since last sync
              followup_level: last && last.who === "them" ? 0 : undefined,
            },
            { onConflict: "lead_id" },
          );
        if (upErr) {
          console.error("leads_sync upsert", upErr);
          return new Response(`DB error: ${upErr.message}`, {
            status: 500,
            headers: CORS,
          });
        }

        // LIVE branch: client just replied → generate suggestion now.
        let liveSuggestionId: string | null = null;
        if (last && last.who === "them") {
          // Skip if we already have a pending live suggestion for a newer-or-equal message.
          const { data: existing } = await supabaseAdmin
            .from("pending_suggestions")
            .select("id, triggered_by_message_at")
            .eq("lead_id", leadId)
            .eq("kind", "live")
            .eq("status", "pending")
            .maybeSingle();
          const shouldGen =
            !existing ||
            !existing.triggered_by_message_at ||
            new Date(existing.triggered_by_message_at).getTime() <
              last.at.getTime();
          if (shouldGen) {
            if (existing) {
              // supersede stale draft
              await supabaseAdmin
                .from("pending_suggestions")
                .update({ status: "skipped" })
                .eq("id", existing.id);
            }
            const gen = await generateSuggestion({
              leadId,
              responsibleUser,
              messages: msgs,
              kind: "live",
            });
            if ("text" in gen && gen.text) {
              liveSuggestionId = await upsertPendingSuggestion({
                leadId,
                responsibleUser,
                kind: "live",
                text: gen.text,
                triggeredByMessageAt: last.at,
              });
            } else if ("error" in gen) {
              console.error("live gen error", gen.error);
              const reason = String(gen.error).slice(0, 200);
              liveSuggestionId = await upsertPendingSuggestion({
                leadId,
                responsibleUser,
                kind: "live",
                text: `⚠️ AI is temporarily unavailable. Reply manually or click "Regenerate".\n(reason: ${reason})`,
                triggeredByMessageAt: last.at,
              });
            }
          } else {
            liveSuggestionId = existing?.id ?? null;
          }
        }

        return new Response(
          JSON.stringify({
            ok: true,
            messages: msgs.length,
            lastMessageFrom: last?.who ?? null,
            lastMessageAt: last?.at.toISOString() ?? null,
            liveSuggestionId,
          }),
          {
            status: 200,
            headers: { ...CORS, "Content-Type": "application/json" },
          },
        );
      },
    },
  },
});
import { createFileRoute } from "@tanstack/react-router";
import "@tanstack/react-start";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { parseConversation, lastMessage } from "@/lib/conversation-parser";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
};

export const Route = createFileRoute("/api/public/suggestions")({
  server: {
    handlers: {
      OPTIONS: async () =>
        new Response(null, { status: 204, headers: CORS }),
      GET: async ({ request }: { request: Request }) => {
        const url = new URL(request.url);
        const kind = url.searchParams.get("kind");
        const responsibleUser = url.searchParams.get("responsibleUser");
        let q = supabaseAdmin
          .from("pending_suggestions")
          .select(
            "id, lead_id, responsible_user, kind, followup_level, suggestion_text, triggered_by_message_at, created_at",
          )
          .eq("status", "pending")
          .order("created_at", { ascending: false })
          .limit(100);
        if (kind === "live" || kind === "push") q = q.eq("kind", kind);
        if (responsibleUser) q = q.eq("responsible_user", responsibleUser);
        const { data, error } = await q;
        if (error) {
          return new Response(`DB error: ${error.message}`, {
            status: 500,
            headers: CORS,
          });
        }

        // Attach the lead's last incoming message so the editor can quote it
        // in the Reason block (mirrors the Drafts card).
        const items = data ?? [];
        const leadIds = Array.from(new Set(items.map((i) => i.lead_id)));
        let leadMap = new Map<string, string>();
        if (leadIds.length) {
          const { data: leads } = await supabaseAdmin
            .from("leads_sync")
            .select("lead_id, content")
            .in("lead_id", leadIds);
          for (const l of leads ?? []) {
            const msgs = parseConversation(l.content || "");
            const lastThem = [...msgs].reverse().find((m) => m.who === "them");
            const last = lastThem || lastMessage(msgs);
            if (last) {
              leadMap.set(l.lead_id, last.text.slice(0, 240));
            }
          }
        }
        const enriched = items.map((i) => ({
          ...i,
          last_lead_text: leadMap.get(i.lead_id) || null,
        }));

        return new Response(JSON.stringify({ items: enriched }), {
          status: 200,
          headers: { ...CORS, "Content-Type": "application/json" },
        });
      },
    },
  },
});
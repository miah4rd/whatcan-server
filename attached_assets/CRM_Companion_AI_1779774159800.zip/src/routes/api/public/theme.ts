import { createFileRoute } from "@tanstack/react-router";
import "@tanstack/react-start";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
  "Cache-Control": "public, max-age=30",
};

// Live theme + labels for the Copilot Chrome extension.
// Edit values here and changes apply on the next page refresh in the CRM —
// no need to re-download the extension zip.
const THEME = {
  version: 7,
  // Full CSS for the shadow-root widget. Must stay in sync with extension/content.js.
  css: `
    :host, * { box-sizing: border-box; }
    .wrap { font-family: Roboto, -apple-system, BlinkMacSystemFont, "Segoe UI", Inter, sans-serif; color: #e6e8ee; }
    .panel { width: 420px; max-width: calc(100vw - 32px); max-height: calc(100vh - 60px); display:flex; flex-direction:column; background: #273444; border: 1px solid #3a4a5e; border-radius: 8px; box-shadow: 0 18px 48px rgba(0,0,0,.55); overflow: hidden; animation: in .25s ease-out; }
    .panel > .hd, .panel > .reason, .panel > .actions { flex: 0 0 auto; }
    .panel > .body { flex: 1 1 auto; overflow-y: auto; min-height: 0; scrollbar-width: thin; scrollbar-color: #3a4a5e transparent; }
    .panel > .body::-webkit-scrollbar { width: 8px; }
    .panel > .body::-webkit-scrollbar-thumb { background: #3a4a5e; border-radius: 4px; }
    @keyframes in { from { transform: translateY(8px); opacity: 0 } to { transform: none; opacity: 1 } }
    .hd { padding: 12px 14px; border-bottom: 1px solid #3a4a5e; background: #2c3e50; }
    .hdtop { display:flex; align-items:center; justify-content:space-between; gap:10px; }
    .badge { display:flex; align-items:center; gap: 9px; min-width: 0; flex:1; }
    .spark { width:28px; height:28px; border-radius:6px; background:#2196f3; display:grid; place-items:center; color:#fff; font-weight:900; font-size:15px; flex:none; }
    .who { font-size: 12.5px; font-weight: 800; color: #ffffff; line-height: 1.2; text-transform: uppercase; letter-spacing: .12em; }
    .who .arr { color: #5e6680; font-weight: 400; margin-left: 4px; font-size: 12px; }
    .sub { font-size: 13px; color: #8a96a8; margin-top: 4px; white-space: nowrap; overflow:hidden; text-overflow:ellipsis; max-width:280px; }
    .icons { display:flex; gap:2px; }
    .ib { width:28px; height:28px; border-radius:4px; background:transparent; border:0; color:#8a96a8; cursor:pointer; display:grid; place-items:center; font-size:16px; }
    .ib:hover { background:rgba(255,255,255,.08); color:#fff; }
    .leadbtn { width:100%; margin-top:10px; height:32px; border-radius:6px; border:1px solid #3a4a5e; background:transparent; color:#90caf9; cursor:pointer; font-size:12px; font-weight:700; display:flex; align-items:center; justify-content:center; gap:7px; }
    .leadbtn:hover { background:rgba(33,150,243,.1); border-color:#2196f3; color:#bbdefb; }
    .reason { padding: 12px 14px; background: rgba(33,150,243,.08); border-bottom: 1px solid #3a4a5e; border-left: 3px solid #2196f3; display:flex; gap:9px; align-items:flex-start; }
    .reason .icon { color:#64b5f6; font-size:17px; flex:none; margin-top:1px; }
    .reason .txt { font-size: 14px; line-height: 1.55; color:#e6e8ee; font-weight:500; }
    .reason .lbl { display:block; font-size: 11px; font-weight: 800; letter-spacing: .14em; text-transform: uppercase; color:#64b5f6; margin-bottom: 6px; }
    .body { padding: 12px 14px 10px; background:#273444; }
    .label { font-size: 11px; font-weight:700; letter-spacing:.12em; text-transform:uppercase; color:#8a96a8; margin-bottom:7px; }
    .msg { font-size: 15px; line-height: 1.6; color:#e6e8ee; white-space: pre-wrap; min-height: 80px; }
    .skel { display:flex; flex-direction:column; gap:7px; padding: 4px 0 8px; }
    .skel div { height:10px; background:rgba(255,255,255,.07); border-radius:4px; animation: p 1.2s ease-in-out infinite; }
    @keyframes p { 0%,100% {opacity:.5} 50% {opacity:1} }
    .err { color: #fca5a5; font-size: 13px; padding: 6px 0; }
    .ta { width:100%; background:#1d2a3a; color:#e6e8ee; border:1px solid #2196f3; border-radius:6px; padding:10px 12px; font-size:14.5px; font-family:inherit; resize:vertical; min-height:96px; }
    .hint { font-size: 12px; color:#8a96a8; margin-top: 7px; }
    .edittools { display:flex; gap:6px; margin-top:8px; }
    .aiinput { flex:1; height:36px; background:#1d2a3a; color:#e6e8ee; border:1px solid #3a4a5e; border-radius:6px; padding:0 10px; font-size:13.5px; font-family:inherit; }
    .mini { height:36px; border-radius:6px; border:1px solid #3a4a5e; background:transparent; color:#cfd5e3; cursor:pointer; padding:0 12px; font-size:13px; font-weight:700; }
    .mini:hover:not(:disabled) { background:rgba(255,255,255,.08); color:#fff; }
    .mini:disabled { opacity:.4; cursor:default; }
    .actions { padding: 10px 12px; border-top: 1px solid #3a4a5e; background: #2c3e50; display:grid; grid-template-columns:1fr 1fr 1fr; gap:7px; }
    .actions.editing { grid-template-columns:1fr 1fr; }
    .primary { height:40px; border:0; border-radius:4px; background:#2196f3; color:#fff; font-weight:700; font-size:13.5px; cursor:pointer; text-transform:uppercase; letter-spacing:.06em; }
    .primary:hover:not(:disabled) { background:#1e88e5; }
    .primary:disabled { opacity:.4; cursor:default; }
    .secondary { height:40px; border-radius:4px; border:1px solid #3a4a5e; background:transparent; color:#cfd5e3; cursor:pointer; font-size:13.5px; font-weight:700; text-transform:uppercase; letter-spacing:.06em; }
    .secondary:hover:not(:disabled) { background:rgba(255,255,255,.08); color:#fff; }
    .secondary:disabled { opacity:.4; cursor:default; }
    .bubble { width:52px; height:52px; border-radius:50%; background:#2196f3; color:#fff; display:grid; place-items:center; box-shadow: 0 10px 30px rgba(33,150,243,.4); cursor:pointer; border:0; font-weight:900; font-size:22px; position: relative; }
    .bubble.sleep { opacity: .55; }
    .bubble.sleep:hover { opacity: 1; }
    .bubble .dot { position:absolute; top:-3px; right:-3px; background:#ef4444; color:#fff; font-size:10px; font-weight:700; min-width:18px; height:18px; border-radius:9px; display:grid; place-items:center; padding:0 4px; border: 2px solid #273444; animation: pulse 2s infinite; }
    @keyframes pulse { 0%,100% { box-shadow: 0 0 0 0 rgba(239,68,68,.6) } 50% { box-shadow: 0 0 0 8px rgba(239,68,68,0) } }
    .detail { padding: 10px 14px 14px; border-top: 1px solid #3a4a5e; background:#1d2a3a; max-height: 220px; overflow:auto; }
    .detail .row { display:flex; gap:8px; margin-bottom: 8px; font-size: 12px; }
    .detail .k { color:#8a96a8; min-width: 64px; }
    .detail .v { color:#e6e8ee; }
    .detail .msgs { margin-top: 10px; padding-top: 10px; border-top: 1px dashed #3a4a5e; }
    .detail .m { font-size: 11.5px; line-height: 1.5; margin-bottom: 6px; color:#cfd5e3; }
    .detail .tag { display:inline-block; font-size: 9px; font-weight: 700; padding: 1px 5px; border-radius: 3px; margin-right: 6px; text-transform: uppercase; letter-spacing: .06em; }
    .tag.b { background:#3a4a5e; color:#cfd5e3; }
    .tag.l { background: rgba(33,150,243,.2); color:#64b5f6; }
    .empty { padding: 16px; text-align:center; font-size:12px; color:#8a96a8; }
    .rate { display:flex; gap:6px; margin-top:8px; align-items:center; font-size:11px; color:#8a96a8; }
    .rate .lbl { letter-spacing:.1em; text-transform:uppercase; font-weight:700; }
    .rate .rb { height:26px; padding:0 9px; border-radius:4px; border:1px solid #3a4a5e; background:transparent; color:#cfd5e3; cursor:pointer; font-size:13px; }
    .rate .rb:hover { background:rgba(255,255,255,.08); color:#fff; }
    .rate .rb.on { background:#2196f3; border-color:#2196f3; color:#fff; }
    .rate .thanks { color:#a7f3d0; font-weight:700; }
    .tabs { display:flex; gap:4px; padding: 10px 12px; background:#273444; border-bottom:1px solid #3a4a5e; flex:0 0 auto; position:relative; }
    .tabwrap { display:flex; gap:4px; padding:4px; border-radius:999px; background:rgba(33,150,243,.06); border:1px solid rgba(33,150,243,.12); width:100%; }
    .tab { flex:1; position:relative; background:transparent; border:0; color:#8a96a8; cursor:pointer; padding:7px 12px; font-size:11.5px; font-weight:700; text-transform:uppercase; letter-spacing:.08em; display:flex; align-items:center; justify-content:center; gap:7px; border-radius:999px; transition: color .18s ease, background .18s ease, box-shadow .18s ease; }
    .tab .dot { width:6px; height:6px; border-radius:50%; background:var(--mark,#8a96a8); flex:none; }
    .tab:hover { color:#cfd5e3; }
    .tab.on { color:#fff; background:linear-gradient(135deg,#2196f3,#22d3ee); box-shadow:0 6px 18px -6px rgba(33,150,243,.7), inset 0 1px 0 rgba(255,255,255,.18); }
    .tab.on .dot { background:#fff; box-shadow:0 0 6px rgba(255,255,255,.7); }
    .tab.live { --mark:#34d399; }
    .tab.push { --mark:#fbbf24; }
    .tab.drafts { --mark:#60a5fa; }
    .tab .cnt { background:rgba(255,255,255,.08); color:#cfd5e3; font-size:10px; min-width:18px; padding:1px 6px; border-radius:999px; font-weight:700; text-align:center; line-height:1.4; }
    .tab.on .cnt { background:rgba(255,255,255,.22); color:#fff; }
    .tab .pulse { width:6px; height:6px; border-radius:50%; background:#34d399; box-shadow:0 0 0 0 rgba(52,211,153,.55); animation: tabpulse 1.8s ease-out infinite; flex:none; }
    .tab.on .pulse { background:#fff; box-shadow:0 0 0 0 rgba(255,255,255,.55); }
    @keyframes tabpulse { 0% { box-shadow:0 0 0 0 rgba(52,211,153,.55) } 70% { box-shadow:0 0 0 6px rgba(52,211,153,0) } 100% { box-shadow:0 0 0 0 rgba(52,211,153,0) } }
    .list { padding: 8px 10px; display:flex; flex-direction:column; gap:8px; }
    .li { position:relative; padding:11px 13px 11px 16px; background:#1d2a3a; border:1px solid #3a4a5e; border-radius:8px; cursor:pointer; transition: border-color .15s ease, background .15s ease, transform .15s ease; overflow:hidden; }
    .li::before { content:""; position:absolute; left:0; top:0; bottom:0; width:3px; background:var(--accent,#2196f3); opacity:.7; }
    .li.live { --accent:#34d399; }
    .li.push { --accent:#fbbf24; }
    .li:hover { border-color:var(--accent,#2196f3); background:#22324a; transform: translateX(1px); }
    .li .top { display:flex; justify-content:space-between; align-items:center; gap:8px; font-size:11px; color:#8a96a8; margin-bottom:6px; }
    .li .top .lead { font-weight:700; color:#cfd5e3; letter-spacing:.02em; }
    .li .top .meta { display:flex; align-items:center; gap:6px; }
    .li .top .lvl { background:rgba(251,191,36,.15); color:#fcd34d; padding:1px 6px; border-radius:999px; font-weight:700; font-size:10px; letter-spacing:.04em; }
    .li .prv { font-size:13px; color:#e6e8ee; line-height:1.5; display:-webkit-box; -webkit-line-clamp:3; -webkit-box-orient:vertical; overflow:hidden; }
    .li .foot { margin-top:8px; display:flex; align-items:center; gap:6px; font-size:10.5px; color:#7a8699; font-weight:600; letter-spacing:.06em; text-transform:uppercase; }
    .li .foot .arrow { margin-left:auto; color:var(--accent,#2196f3); font-size:14px; opacity:.7; }
    .back { background:transparent; border:0; color:#8a96a8; cursor:pointer; font-size:12px; padding:0; display:flex; align-items:center; gap:4px; margin-bottom:4px; }
    .back:hover { color:#fff; }
  `,
  labels: {
    headerTitle: "Follow-up nudge",
    reasonLabel: "Why this follow-up now",
    suggestedLabel: "Suggested message",
    editLabel: "Edit message",
    approveBtn: "✓ Approve",
    skipBtn: "✕ Skip",
    editBtn: "✎ Edit",
    saveBtn: "✓ Save",
    cancelBtn: "Cancel",
    aiPlaceholder: "Tell AI what to change, or use voice…",
    aiRewriteBtn: "AI rewrite",
    editHint: "Edit manually, type an instruction, or dictate it with the mic.",
    sleepingTitle: "Sleeping",
    sleepingBody: "Copilot only wakes up when a lead needs follow-up.",
  },
};

export const Route = createFileRoute("/api/public/theme")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: CORS }),
      GET: async () =>
        new Response(JSON.stringify(THEME), {
          status: 200,
          headers: { ...CORS, "Content-Type": "application/json" },
        }),
    },
  },
});

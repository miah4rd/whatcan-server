import { createFileRoute } from "@tanstack/react-router";
import "@tanstack/react-start";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { parseConversation } from "@/lib/conversation-parser";
import { generateSuggestion, upsertPendingSuggestion } from "@/lib/ai-suggest";

// hours after our last message to fire each follow-up.
// followup_level reflects how many push follow-ups have already been queued/sent.
const CADENCE_HOURS = [24, 24 * 3, 24 * 5, 24 * 7, 24 * 10];

function nextDelayHours(level: number): number {
  if (level < CADENCE_HOURS.length) return CADENCE_HOURS[level];
  return CADENCE_HOURS[CADENCE_HOURS.length - 1];
}

export const Route = createFileRoute("/api/public/check-followups")({
  server: {
    handlers: {
      POST: async () => {
        const { data: leads, error } = await supabaseAdmin
          .from("leads_sync")
          .select("lead_id, content, responsible_user, last_message_at, last_message_from, followup_level")
          .eq("last_message_from", "us")
          .not("last_message_at", "is", null)
          .limit(200);
        if (error) {
          return new Response(`DB error: ${error.message}`, { status: 500 });
        }

        const now = Date.now();
        let processed = 0;
        let created = 0;
        for (const lead of leads ?? []) {
          processed++;
          const last = lead.last_message_at
            ? new Date(lead.last_message_at).getTime()
            : 0;
          const level = lead.followup_level ?? 0;
          const delay = nextDelayHours(level) * 3600 * 1000;
          if (now - last < delay) continue;

          // Skip if a pending push already exists.
          const { data: existing } = await supabaseAdmin
            .from("pending_suggestions")
            .select("id")
            .eq("lead_id", lead.lead_id)
            .eq("kind", "push")
            .eq("status", "pending")
            .maybeSingle();
          if (existing) continue;

          const msgs = parseConversation(lead.content);
          const gen = await generateSuggestion({
            leadId: lead.lead_id,
            responsibleUser: lead.responsible_user,
            messages: msgs,
            kind: "push",
            followupLevel: level + 1,
          });
          let text: string;
          if ("error" in gen) {
            console.error("push gen error", lead.lead_id, gen.error);
            const reason = String(gen.error).slice(0, 200);
            text = `⚠️ AI follow-up unavailable — lead hasn't replied for a while, consider nudging manually.\n(reason: ${reason})`;
          } else {
            text = gen.text;
          }
          const id = await upsertPendingSuggestion({
            leadId: lead.lead_id,
            responsibleUser: lead.responsible_user,
            kind: "push",
            followupLevel: level + 1,
            text,
            triggeredByMessageAt: lead.last_message_at
              ? new Date(lead.last_message_at)
              : null,
          });
          if (id) {
            created++;
            // Advance the level so the next pass uses the next cadence step.
            await supabaseAdmin
              .from("leads_sync")
              .update({ followup_level: level + 1 })
              .eq("lead_id", lead.lead_id);
          }
        }

        return new Response(
          JSON.stringify({ ok: true, processed, created }),
          {
            status: 200,
            headers: { "Content-Type": "application/json" },
          },
        );
      },
    },
  },
});
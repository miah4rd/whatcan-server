import { createFileRoute } from "@tanstack/react-router";
import "@tanstack/react-start";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

type Msg = { from: "lead" | "broker"; text: string };

type Body = {
  guide: string;
  lead: { name: string; company: string; stage: string };
  messages: Msg[];
  brokerName?: string;
  brokerId?: string;
  leadId?: string;
  feedback?: string;
  previous?: string;
  model?: string;
};

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
};

const MODEL_MINI = "openai/gpt-5-mini";
const MODEL_STRONG = "openai/gpt-5";
const MODEL_WHITELIST = new Set([
  "openai/gpt-5-mini",
  "openai/gpt-5",
  "google/gemini-2.5-pro",
  "google/gemini-3-flash-preview",
]);

const OBJECTION_KEYWORDS = [
  "дорог", "скидк", "подума", "конкурент", "юрист", "договор", "налог",
  "ипотек", "наличн",
  "mortgage", "lawyer", "expensive", "discount", "competitor", "vip", "cash",
];
const COMPLEX_STAGES = [
  "negotiation", "contract", "closing",
  "переговор", "договор", "закрыт",
];

function pickModel(body: Body, lastLeadText: string): { model: string; reason: string } {
  if (body.model && MODEL_WHITELIST.has(body.model)) {
    return { model: body.model, reason: "override" };
  }
  const reasons: string[] = [];
  if (body.messages.length >= 8) reasons.push("long-history");
  if (lastLeadText.length > 350) reasons.push("long-lead-message");
  if (body.feedback && body.feedback.trim()) reasons.push("revision");

  const stage = (body.lead.stage || "").toLowerCase();
  if (COMPLEX_STAGES.some((s) => stage.includes(s))) reasons.push("complex-stage");

  const recentLead = [...body.messages]
    .filter((m) => m.from === "lead")
    .slice(-3)
    .map((m) => String(m.text).toLowerCase())
    .join(" ");
  if (OBJECTION_KEYWORDS.some((kw) => recentLead.includes(kw))) {
    reasons.push("objection-keyword");
  }

  return reasons.length
    ? { model: MODEL_STRONG, reason: reasons.join(",") }
    : { model: MODEL_MINI, reason: "default" };
}

async function callGateway(
  key: string,
  model: string,
  system: string,
  user: string,
): Promise<{ ok: true; text: string } | { ok: false; status: number; body: string }> {
  const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Lovable-API-Key": key,
      "X-Lovable-AIG-SDK": "vercel-ai-sdk",
    },
    body: JSON.stringify({
      model,
      messages: [
        { role: "system", content: system },
        { role: "user", content: user },
      ],
    }),
  });
  if (!res.ok) {
    return { ok: false, status: res.status, body: await res.text() };
  }
  const json = (await res.json()) as {
    choices?: { message?: { content?: string } }[];
  };
  return { ok: true, text: json.choices?.[0]?.message?.content?.trim() ?? "" };
}

export const Route = createFileRoute("/api/public/suggest")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: CORS }),
      POST: async ({ request }: { request: Request }) => {
        const key = process.env.LOVABLE_API_KEY;
        if (!key)
          return new Response("Missing LOVABLE_API_KEY", { status: 500, headers: CORS });

        let body: Body;
        try {
          body = (await request.json()) as Body;
        } catch {
          return new Response("Invalid JSON", { status: 400, headers: CORS });
        }

        // light input guards
        if (
          !body?.guide ||
          !body?.lead?.name ||
          !Array.isArray(body.messages) ||
          body.messages.length > 50 ||
          body.guide.length > 8000
        ) {
          return new Response("Invalid payload", { status: 400, headers: CORS });
        }

        const transcript = body.messages
          .slice(-20)
          .map((m) => `${m.from === "broker" ? "BROKER" : "LEAD"}: ${String(m.text).slice(0, 1200)}`)
          .join("\n");

        const brokerId = (body.brokerId || body.brokerName || "anon").toLowerCase().slice(0, 64);

        // Pull few-shot examples for this broker: top 5 "good", top 3 "bad".
        let fewShotBlock = "";
        try {
          const { data: good } = await supabaseAdmin
            .from("suggestion_feedback")
            .select("final_text, suggestion_id, ai_suggestions(suggestion_text)")
            .eq("broker_id", brokerId)
            .eq("verdict", "good")
            .order("created_at", { ascending: false })
            .limit(5);
          const { data: bad } = await supabaseAdmin
            .from("suggestion_feedback")
            .select("ai_suggestions(suggestion_text)")
            .eq("broker_id", brokerId)
            .eq("verdict", "bad")
            .order("created_at", { ascending: false })
            .limit(3);

          const goodLines = (good ?? [])
            .map((r: any) => (r.final_text || r.ai_suggestions?.suggestion_text || "").trim())
            .filter(Boolean);
          const badLines = (bad ?? [])
            .map((r: any) => (r.ai_suggestions?.suggestion_text || "").trim())
            .filter(Boolean);

          if (goodLines.length || badLines.length) {
            fewShotBlock = `\n\nBROKER STYLE CALIBRATION (examples from this specific broker):`;
            if (goodLines.length) {
              fewShotBlock += `\n\nGOOD examples — match this tone, length, and structure:\n` +
                goodLines.map((t, i) => `--- good #${i + 1} ---\n${t}`).join("\n\n");
            }
            if (badLines.length) {
              fewShotBlock += `\n\nBAD examples — the broker rejected these. Avoid this style:\n` +
                badLines.map((t, i) => `--- bad #${i + 1} ---\n${t}`).join("\n\n");
            }
          }
        } catch (e) {
          console.error("few-shot fetch failed", e);
        }

        const system = `You are an AI sales copilot embedded in a CRM. You help brokers write the next follow-up message to a lead.
You MUST obey the broker's playbook below. Return ONLY the message body — no preamble, no "Here is...", no quotes, no subject line. Plain text, ready to send.

PLAYBOOK:
${body.guide}${fewShotBlock}`;

        const user = `Lead: ${body.lead.name} (${body.lead.company}) — stage: ${body.lead.stage}
Broker name: ${body.brokerName ?? "Alex"}

Conversation so far:
${transcript}

${body.previous && body.feedback
  ? `Previous draft you proposed:\n"""${body.previous}"""\n\nThe broker wants you to revise it with this feedback: "${body.feedback}"\nProduce a new draft.`
  : `Write the next follow-up message from the broker to the lead.`}`;

        const lastLead = [...body.messages].reverse().find((m) => m.from === "lead");
        const picked = pickModel(body, lastLead ? String(lastLead.text) : "");
        console.log(`[suggest] model=${picked.model} reason=${picked.reason} broker=${brokerId}`);

        let modelUsed = picked.model;
        let degraded = false;
        let result = await callGateway(key, modelUsed, system, user);

        // Auto-fallback: if strong model rate-limited or out of credits, retry on mini.
        if (!result.ok && modelUsed === MODEL_STRONG && (result.status === 429 || result.status === 402)) {
          console.warn(`[suggest] ${modelUsed} returned ${result.status}, falling back to ${MODEL_MINI}`);
          modelUsed = MODEL_MINI;
          degraded = true;
          result = await callGateway(key, modelUsed, system, user);
        }

        if (!result.ok) {
          return new Response(`AI error ${result.status}: ${result.body}`, {
            status: result.status,
            headers: CORS,
          });
        }
        const text = result.text;

        const rationale = lastLead
          ? `References lead's last point: "${String(lastLead.text).slice(0, 70)}${lastLead.text.length > 70 ? "…" : ""}". One CTA, under 90 words, no apology.`
          : `Soft nudge — last broker message had no reply. New angle per playbook cadence.`;

        // Log this suggestion so we can collect feedback against it.
        let suggestionId: string | null = null;
        try {
          const { data: inserted, error: insErr } = await supabaseAdmin
            .from("ai_suggestions")
            .insert({
              broker_id: brokerId,
              lead_id: body.leadId ?? null,
              lead_name: body.lead.name,
              lead_company: body.lead.company,
              lead_stage: body.lead.stage,
              prompt_messages: body.messages as any,
              suggestion_text: text,
              rationale,
              model: degraded ? `${modelUsed} (degraded from ${MODEL_STRONG})` : modelUsed,
            })
            .select("id")
            .single();
          if (insErr) console.error("ai_suggestions insert error", insErr);
          suggestionId = inserted?.id ?? null;
        } catch (e) {
          console.error("ai_suggestions insert threw", e);
        }

        return new Response(JSON.stringify({ text, rationale, suggestionId }), {
          status: 200,
          headers: { ...CORS, "Content-Type": "application/json" },
        });
      },
    },
  },
});
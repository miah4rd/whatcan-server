import { createFileRoute } from "@tanstack/react-router";
import "@tanstack/react-start";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
};

export const Route = createFileRoute("/api/public/skip")({
  server: {
    handlers: {
      OPTIONS: async () =>
        new Response(null, { status: 204, headers: CORS }),
      POST: async ({ request }: { request: Request }) => {
        const body = (await request.json().catch(() => null)) as
          | { suggestionId?: string }
          | null;
        if (!body?.suggestionId) {
          return new Response("Invalid payload", { status: 400, headers: CORS });
        }
        const { error } = await supabaseAdmin
          .from("pending_suggestions")
          .update({ status: "skipped" })
          .eq("id", body.suggestionId)
          .eq("status", "pending");
        if (error) {
          return new Response(`DB error: ${error.message}`, {
            status: 500,
            headers: CORS,
          });
        }
        return new Response(JSON.stringify({ ok: true }), {
          status: 200,
          headers: { ...CORS, "Content-Type": "application/json" },
        });
      },
    },
  },
});
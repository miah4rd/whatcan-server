import { createFileRoute } from "@tanstack/react-router";
import "@tanstack/react-start";

type Msg = { from: "lead" | "broker"; text: string };

type Body = {
  guide: string;
  lead: { name: string; company: string; stage: string };
  messages: Msg[];
  brokerName?: string;
  feedback?: string; // optional refinement instruction
  previous?: string; // previous suggestion to refine
};

export const Route = createFileRoute("/api/suggest")({
  server: {
    handlers: {
      POST: async ({ request }: { request: Request }) => {
        const key = process.env.LOVABLE_API_KEY;
        if (!key) return new Response("Missing LOVABLE_API_KEY", { status: 500 });

        let body: Body;
        try {
          body = (await request.json()) as Body;
        } catch {
          return new Response("Invalid JSON", { status: 400 });
        }

        const transcript = body.messages
          .map((m) => `${m.from === "broker" ? "BROKER" : "LEAD"}: ${m.text}`)
          .join("\n");

        const system = `You are an AI sales copilot embedded in a CRM. You help brokers write the next follow-up message to a lead.
You MUST obey the broker's playbook below. Return ONLY the message body — no preamble, no "Here is...", no quotes, no subject line. Plain text, ready to send.

PLAYBOOK:
${body.guide}`;

        const user = `Lead: ${body.lead.name} (${body.lead.company}) — stage: ${body.lead.stage}
Broker name: ${body.brokerName ?? "Alex"}

Conversation so far:
${transcript}

${body.previous && body.feedback
  ? `Previous draft you proposed:\n"""${body.previous}"""\n\nThe broker wants you to revise it with this feedback: "${body.feedback}"\nProduce a new draft.`
  : `Write the next follow-up message from the broker to the lead.`}`;

        const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Lovable-API-Key": key,
            "X-Lovable-AIG-SDK": "vercel-ai-sdk",
          },
          body: JSON.stringify({
            model: "google/gemini-3-flash-preview",
            messages: [
              { role: "system", content: system },
              { role: "user", content: user },
            ],
          }),
        });

        if (!res.ok) {
          const txt = await res.text();
          return new Response(`AI error ${res.status}: ${txt}`, { status: res.status });
        }
        const json = (await res.json()) as {
          choices?: { message?: { content?: string } }[];
        };
        const text = json.choices?.[0]?.message?.content?.trim() ?? "";

        // simple rationale derived from playbook + transcript
        const lastLead = [...body.messages].reverse().find((m) => m.from === "lead");
        const rationale = lastLead
          ? `References lead's last point: "${lastLead.text.slice(0, 70)}${lastLead.text.length > 70 ? "…" : ""}". One CTA, under 90 words, no apology.`
          : `Soft nudge — last broker message had no reply. New angle per playbook cadence.`;

        return Response.json({ text, rationale });
      },
    },
  },
});
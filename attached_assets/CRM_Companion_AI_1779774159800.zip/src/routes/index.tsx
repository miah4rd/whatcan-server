import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { Sparkles, X, Loader2, Download, Chrome, Bell } from "lucide-react";
import { SEED_LEADS } from "@/lib/crm-data";

const EXTENSION_VERSION = "1.4.5";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Copilot — AI follow-up nudges for brokers" },
      {
        name: "description",
        content:
          "A lightweight plugin that pops up inside your CRM and suggests the next follow-up message based on your playbook. Approve in one click.",
      },
    ],
  }),
  component: Index,
});

function Index() {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [installOpen, setInstallOpen] = useState(false);
  const [leadIdx, setLeadIdx] = useState(0);

  const triggerFollowUp = () => {
    const lead = SEED_LEADS[leadIdx % SEED_LEADS.length];
    setLeadIdx((i) => i + 1);
    iframeRef.current?.contentWindow?.postMessage(
      { type: "COPILOT_FOLLOW_UP_DUE", lead, delayMs: 0 },
      "*"
    );
  };

  const toggleWidget = () => {
    iframeRef.current?.contentWindow?.postMessage(
      { type: "COPILOT_TOGGLE" },
      "*"
    );
  };

  const addLive = () => {
    iframeRef.current?.contentWindow?.postMessage(
      { type: "COPILOT_PREVIEW_ADD_LIVE" },
      "*"
    );
  };
  const addPush = () => {
    iframeRef.current?.contentWindow?.postMessage(
      { type: "COPILOT_PREVIEW_ADD_PUSH" },
      "*"
    );
  };

  return (
    <div className="relative min-h-screen bg-[oklch(0.16_0.018_250)] text-foreground">
      {/* Top-right install CTA */}
      <button
        onClick={() => setInstallOpen(true)}
        className="fixed top-5 right-5 z-40 inline-flex items-center gap-2 rounded-full border border-copilot/40 bg-card/80 px-3.5 py-2 text-xs font-semibold text-foreground backdrop-blur hover:border-copilot hover:bg-card"
      >
        <Chrome className="h-3.5 w-3.5 text-copilot" />
        Install Chrome extension
        <span className="ml-1 rounded-full bg-copilot/20 px-1.5 py-0.5 text-[10px] font-bold text-copilot">
          v{EXTENSION_VERSION}
        </span>
      </button>

      <div className="mx-auto max-w-6xl px-6 pt-20 pb-16">
        {/* Hero */}
        <header className="mb-10 max-w-2xl">
          <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-copilot/30 bg-copilot/10 px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.14em] text-copilot">
            <Sparkles className="h-3 w-3" /> Live preview
          </div>
          <h1 className="text-4xl font-bold leading-[1.1] tracking-tight md:text-5xl">
            The follow-up plugin that lives inside your CRM.
          </h1>
          <p className="mt-4 text-base leading-relaxed text-muted-foreground">
            A floating copilot that watches your amoCRM threads and pops up when a
            lead needs a nudge — drafted in your tone, ready to send in one click.
            The preview below runs the <strong>exact same code</strong> as the
            installed extension.
          </p>
        </header>

        {/* Demo triggers */}
        <div className="mb-4 flex flex-wrap items-center gap-2">
          <button
            onClick={triggerFollowUp}
            className="inline-flex items-center gap-2 rounded-md bg-[image:var(--gradient-copilot)] px-4 py-2 text-sm font-semibold text-primary-foreground shadow-[var(--shadow-glow)] hover:opacity-95"
          >
            <Bell className="h-4 w-4" /> Trigger follow-up
          </button>
          <button
            onClick={toggleWidget}
            className="inline-flex items-center gap-2 rounded-md border border-border bg-card/60 px-3 py-2 text-xs font-semibold text-foreground hover:border-copilot/60"
          >
            Toggle widget
          </button>
          <button
            onClick={addLive}
            className="inline-flex items-center gap-2 rounded-md border border-border bg-card/60 px-3 py-2 text-xs font-semibold text-foreground hover:border-copilot/60"
          >
            + Live suggestion
          </button>
          <button
            onClick={addPush}
            className="inline-flex items-center gap-2 rounded-md border border-border bg-card/60 px-3 py-2 text-xs font-semibold text-foreground hover:border-copilot/60"
          >
            + Push suggestion
          </button>
          <span className="text-[11px] text-muted-foreground">
            Open the floating bubble (bottom-right of the frame) — header has
            three tabs: Live · Push · Drafts.
          </span>
        </div>

        {/* Live extension preview */}
        <div className="overflow-hidden rounded-xl border border-border bg-black/40 shadow-[var(--shadow-panel)]">
          <div className="flex items-center gap-2 border-b border-border bg-card/60 px-3 py-2">
            <div className="flex gap-1.5">
              <span className="h-2.5 w-2.5 rounded-full bg-red-400/70" />
              <span className="h-2.5 w-2.5 rounded-full bg-amber-400/70" />
              <span className="h-2.5 w-2.5 rounded-full bg-green-400/70" />
            </div>
            <div className="ml-2 text-[11px] text-muted-foreground">
              amoCRM tab — with copilot extension loaded
            </div>
            <div className="ml-auto text-[10px] font-semibold text-copilot">
              extension v{EXTENSION_VERSION}
            </div>
          </div>
          <iframe
            ref={iframeRef}
            src={`/extension-preview/host.html?v=${EXTENSION_VERSION}`}
            title="Copilot extension preview"
            className="block h-[640px] w-full border-0 bg-[#0e1420]"
          />
        </div>

        <p className="mt-3 text-[11px] text-muted-foreground">
          The widget you see here is{" "}
          <code className="rounded bg-card/60 px-1.5 py-0.5">
            extension/content.js
          </code>{" "}
          running unmodified. Updates ship to this preview at the same time as
          the downloaded ZIP.
        </p>
      </div>

      {installOpen && <InstallDrawer onClose={() => setInstallOpen(false)} />}
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/*  Install drawer — download the packaged Chrome extension                   */
/* -------------------------------------------------------------------------- */

function InstallDrawer({ onClose }: { onClose: () => void }) {
  const [downloading, setDownloading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const download = async () => {
    setDownloading(true);
    setError(null);
    try {
      const res = await fetch(`/copilot-extension.zip?v=${EXTENSION_VERSION}`);
      if (!res.ok) throw new Error(`Download failed: ${res.status}`);
      const blob = await res.blob();
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = "copilot-extension.zip";
      a.click();
      URL.revokeObjectURL(a.href);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed");
    } finally {
      setDownloading(false);
    }
  };

  // Close on Esc
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-background/70 backdrop-blur-sm p-4">
      <div className="w-full max-w-md rounded-2xl border border-border bg-card p-5 shadow-[var(--shadow-panel)]">
        <div className="mb-3 flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2">
              <Chrome className="h-4 w-4 text-copilot" />
              <div className="text-sm font-semibold">Install on Chrome</div>
            </div>
            <div className="mt-1 text-[11px] text-muted-foreground">
              The copilot will float over any CRM you open.
            </div>
          </div>
          <button
            onClick={onClose}
            className="grid h-7 w-7 place-items-center rounded-md hover:bg-accent"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <button
          onClick={download}
          disabled={downloading}
          className="inline-flex w-full items-center justify-center gap-2 rounded-md bg-[image:var(--gradient-copilot)] py-2.5 text-sm font-semibold text-primary-foreground shadow-[var(--shadow-glow)] hover:opacity-95 disabled:opacity-60"
        >
          {downloading ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" /> Preparing…
            </>
          ) : (
            <>
              <Download className="h-4 w-4" /> Download copilot-extension.zip
            </>
          )}
        </button>
        {error && <div className="mt-2 text-[11px] text-destructive">{error}</div>}

        <ol className="mt-4 space-y-2 text-[12px] leading-relaxed text-muted-foreground">
          <li>
            <span className="mr-1.5 inline-block rounded bg-secondary px-1.5 py-0.5 text-[10px] font-bold text-foreground">1</span>
            Unzip the downloaded file.
          </li>
          <li>
            <span className="mr-1.5 inline-block rounded bg-secondary px-1.5 py-0.5 text-[10px] font-bold text-foreground">2</span>
            Open <code className="rounded bg-background/60 px-1.5 py-0.5 text-[11px]">chrome://extensions</code> and turn on
            <span className="text-foreground"> Developer mode</span> (top-right).
          </li>
          <li>
            <span className="mr-1.5 inline-block rounded bg-secondary px-1.5 py-0.5 text-[10px] font-bold text-foreground">3</span>
            Click <span className="text-foreground">Load unpacked</span> and select the unzipped folder.
          </li>
          <li>
            <span className="mr-1.5 inline-block rounded bg-secondary px-1.5 py-0.5 text-[10px] font-bold text-foreground">4</span>
            Open your CRM — the nudge will float in the corner. Click the extension icon to edit the playbook.
          </li>
        </ol>
      </div>
    </div>
  );
}

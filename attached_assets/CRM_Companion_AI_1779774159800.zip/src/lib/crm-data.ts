export type Message = {
  id: string;
  from: "lead" | "broker";
  text: string;
  at: string; // ISO
};

export type Lead = {
  id: string;
  name: string;
  company: string;
  stage: "New" | "Discovery" | "Proposal" | "Negotiation" | "Won" | "Lost";
  value: number;
  lastContactDays: number;
  avatarHue: number;
  messages: Message[];
};

export const DEFAULT_GUIDE = `BROKER FOLLOW-UP PLAYBOOK

1. Tone: warm, concise, confident. No corporate fluff. Always address the lead by first name.
2. Cadence:
   - No reply in 24h after initial pitch → soft nudge with new angle (value, case study).
   - No reply in 72h → break-up email offering to pause.
   - After demo/call → recap within 4h, list 2 next steps, propose specific time.
3. Every follow-up must:
   - Reference the last thing the lead said (continuity).
   - Include exactly ONE clear question or CTA.
   - Stay under 90 words.
4. Never:
   - Apologize for following up.
   - Send generic "just checking in".
   - Send pricing in writing before a discovery call.
5. If the lead mentions budget, timeline, or competitors → flag for a call, do NOT reply in text.
6. Sign off as the broker, first name only.`;

const now = Date.now();
const ago = (h: number) => new Date(now - h * 3600 * 1000).toISOString();

export const SEED_LEADS: Lead[] = [
  {
    id: "l1",
    name: "Amelia Reyes",
    company: "Northwind Capital",
    stage: "Discovery",
    value: 48000,
    lastContactDays: 2,
    avatarHue: 165,
    messages: [
      { id: "m1", from: "broker", text: "Hi Amelia — thanks for the intro call yesterday. Sending the one-pager we discussed.", at: ago(54) },
      { id: "m2", from: "lead", text: "Got it, thanks. The numbers look interesting. I need to loop in our COO before the next step — probably next week.", at: ago(48) },
      { id: "m3", from: "broker", text: "Perfect, want me to send a short loom your COO can watch async?", at: ago(46) },
      { id: "m4", from: "lead", text: "Yes please. Also — how flexible is the onboarding timeline?", at: ago(45) },
    ],
  },
  {
    id: "l2",
    name: "Tomáš Novák",
    company: "Helio Logistics",
    stage: "Proposal",
    value: 92000,
    lastContactDays: 4,
    avatarHue: 200,
    messages: [
      { id: "m1", from: "broker", text: "Tomáš, sharing the revised proposal with the volume tier you asked for.", at: ago(110) },
      { id: "m2", from: "lead", text: "Thanks. Reviewing internally.", at: ago(108) },
    ],
  },
  {
    id: "l3",
    name: "Priya Anand",
    company: "Lumen Health",
    stage: "Negotiation",
    value: 145000,
    lastContactDays: 1,
    avatarHue: 320,
    messages: [
      { id: "m1", from: "lead", text: "Hi — legal flagged the auto-renewal clause. Can we make it opt-in instead of opt-out?", at: ago(20) },
      { id: "m2", from: "broker", text: "Checking with our team, back to you today.", at: ago(19) },
    ],
  },
  {
    id: "l4",
    name: "Marcus Field",
    company: "Atlas Build Co.",
    stage: "New",
    value: 22000,
    lastContactDays: 6,
    avatarHue: 30,
    messages: [
      { id: "m1", from: "broker", text: "Marcus, following up on the form you filled out last week — happy to walk through how we'd handle multi-site rollouts.", at: ago(144) },
    ],
  },
];
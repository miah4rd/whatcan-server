import { supabaseAdmin } from "@/integrations/supabase/client.server";
import type { ParsedMessage } from "./conversation-parser";
import { createOpenAICompatible } from "@ai-sdk/openai-compatible";
import { generateText } from "ai";

const DEFAULT_GUIDE = `BROKER FOLLOW-UP PLAYBOOK v4
1. Tone: warm, concise, confident. No corporate fluff. Address the lead by first name when known.
2. Every reply must reference the lead's last message (continuity) and include ONE clear CTA. Under 90 words.
3. Never apologize for following up. Never send generic "just checking in".
4. If the lead asks about price/budget/timeline/competitors → propose a short call instead of answering in text.
5. Sign off as the broker, first name only.`;

export async function generateSuggestion(opts: {
  leadId: string;
  responsibleUser?: string | null;
  messages: ParsedMessage[];
  kind: "live" | "push";
  followupLevel?: number;
}): Promise<{ text: string; model: string } | { error: string }> {
  const key = process.env.LOVABLE_API_KEY;
  if (!key) return { error: "missing LOVABLE_API_KEY" };

  const transcript = opts.messages
    .slice(-25)
    .map(
      (m) =>
        `${m.who === "us" ? "BROKER" : "LEAD"} (${m.author}, ${m.at.toISOString()}): ${m.text.slice(0, 1500)}`,
    )
    .join("\n");

  const brokerName = opts.responsibleUser || "Broker";

  const userPrompt =
    opts.kind === "live"
      ? `Lead just replied. Write the next broker message in reply.\n\nConversation so far:\n${transcript}\n\nBroker name: ${brokerName}`
      : `Lead has NOT replied for a while. This is follow-up #${opts.followupLevel ?? 1}. Write a soft nudge with a new angle, do not repeat the previous broker message.\n\nConversation so far:\n${transcript}\n\nBroker name: ${brokerName}`;

  const system = `You are an AI sales copilot embedded in a CRM. Return ONLY the message body — no preamble, no quotes, no subject line. Plain text ready to send.\n\nPLAYBOOK:\n${DEFAULT_GUIDE}`;

  const modelId = "openai/gpt-5-nano";
  console.log("ai req", {
    leadId: opts.leadId,
    kind: opts.kind,
    msgsCount: opts.messages.length,
    transcriptLen: transcript.length,
    systemLen: system.length,
    promptLen: userPrompt.length,
    modelId,
  });

  const ac = new AbortController();
  const timer = setTimeout(() => ac.abort(), 30_000);
  try {
    const gateway = createOpenAICompatible({
      name: "lovable",
      baseURL: "https://ai.gateway.lovable.dev/v1",
      headers: {
        "Lovable-API-Key": key,
        "X-Lovable-AIG-SDK": "vercel-ai-sdk",
      },
    });
    const { text: raw } = await generateText({
      model: gateway(modelId),
      messages: [
        { role: "system", content: system },
        { role: "user", content: userPrompt },
      ],
      temperature: 0.7,
      abortSignal: ac.signal,
    });
    const text = (raw ?? "").trim();
    if (!text) {
      console.error("ai err empty", { leadId: opts.leadId });
      return { error: "Gateway: empty response" };
    }
    return { text: text.trim(), model: modelId };
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    console.error("ai err", {
      leadId: opts.leadId,
      name: e instanceof Error ? e.name : typeof e,
      msg: msg.slice(0, 500),
    });
    return { error: `Gateway: ${msg.slice(0, 300)}` };
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Insert a pending suggestion only if there's no pending one of the same kind
 * for this lead. Returns the suggestion id (or null if skipped/failed).
 */
export async function upsertPendingSuggestion(row: {
  leadId: string;
  responsibleUser?: string | null;
  kind: "live" | "push";
  followupLevel?: number;
  text: string;
  triggeredByMessageAt?: Date | null;
}): Promise<string | null> {
  const { data: existing } = await supabaseAdmin
    .from("pending_suggestions")
    .select("id")
    .eq("lead_id", row.leadId)
    .eq("kind", row.kind)
    .eq("status", "pending")
    .maybeSingle();
  if (existing) return existing.id;

  const { data, error } = await supabaseAdmin
    .from("pending_suggestions")
    .insert({
      lead_id: row.leadId,
      responsible_user: row.responsibleUser ?? null,
      kind: row.kind,
      followup_level: row.followupLevel ?? null,
      suggestion_text: row.text,
      triggered_by_message_at: row.triggeredByMessageAt
        ? row.triggeredByMessageAt.toISOString()
        : null,
    })
    .select("id")
    .single();
  if (error) {
    console.error("pending insert error", error);
    return null;
  }
  return data.id;
}
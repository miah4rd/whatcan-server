// Parses the CRM conversation transcript into structured messages.
// Format per message header:
//   DD.MM.YYYY HH:MM:SS Name (role - source) → text
// "Our" messages = role contains "менеджер" or "bot" with source "amocrm".

export type ParsedMessage = {
  at: Date;
  who: "us" | "them";
  author: string;
  text: string;
};

const HEADER_RE =
  /(\d{2})\.(\d{2})\.(\d{4})\s+(\d{2}):(\d{2}):(\d{2})\s+([^()→\n]+?)\s*\(([^)]+)\)\s*→\s*/g;

function isOurs(role: string): boolean {
  const r = role.toLowerCase();
  return (
    (r.includes("менеджер") || r.includes("bot") || r.includes("manager")) &&
    r.includes("amocrm")
  );
}

export function parseConversation(content: string): ParsedMessage[] {
  if (!content) return [];
  const text = content.replace(/\r/g, "");
  const matches: { idx: number; end: number; m: RegExpExecArray }[] = [];
  HEADER_RE.lastIndex = 0;
  let m: RegExpExecArray | null;
  while ((m = HEADER_RE.exec(text)) !== null) {
    matches.push({ idx: m.index, end: HEADER_RE.lastIndex, m });
  }
  const out: ParsedMessage[] = [];
  for (let i = 0; i < matches.length; i++) {
    const cur = matches[i];
    const next = matches[i + 1];
    const body = text.slice(cur.end, next ? next.idx : text.length).trim();
    const [, dd, mm, yyyy, hh, mi, ss, author, role] = cur.m;
    const at = new Date(
      Date.UTC(+yyyy, +mm - 1, +dd, +hh, +mi, +ss),
    );
    out.push({
      at,
      who: isOurs(role) ? "us" : "them",
      author: author.trim(),
      text: body,
    });
  }
  return out;
}

export function lastMessage(msgs: ParsedMessage[]): ParsedMessage | null {
  return msgs.length ? msgs[msgs.length - 1] : null;
}